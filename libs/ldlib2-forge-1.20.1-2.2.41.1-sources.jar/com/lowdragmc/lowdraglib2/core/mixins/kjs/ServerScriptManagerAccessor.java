package com.lowdragmc.lowdraglib2.core.mixins.kjs;

import dev.latvian.mods.kubejs.server.ServerScriptManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = ServerScriptManager.class, remap = false)
public interface ServerScriptManagerAccessor {
    @Accessor("instance")
    static ServerScriptManager getStaticInstance() {
        throw new AssertionError();
    }
}
