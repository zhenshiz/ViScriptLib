package com.lowdragmc.lowdraglib2.gui.sync;

import com.lowdragmc.lowdraglib2.LDLib2;
import com.lowdragmc.lowdraglib2.gui.sync.rpc.RPCEvent;
import com.lowdragmc.lowdraglib2.gui.ui.ModularUI;
import com.lowdragmc.lowdraglib2.networking.LDLNetworking;
import com.lowdragmc.lowdraglib2.networking.both.PacketModularUISync;
import com.lowdragmc.lowdraglib2.networking.both.PacketUIRPCEvent;
import com.lowdragmc.lowdraglib2.networking.both.PacketUIRPCEventReturn;
import com.lowdragmc.lowdraglib2.utils.ByteBufUtil;
import com.lowdragmc.lowdraglib2.utils.IdentityMap;
import com.lowdragmc.lowdraglib2.utils.function.LDConsumers;
import lombok.Getter;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public class UISyncManager {
    public final ModularUI modularUI;
    // runtime
    private final IdentityMap<SyncValue<?>> syncValues = new IdentityMap<>();
    private final IdentityMap<RPCEvent> rpcEvents = new IdentityMap<>();

    private final AtomicInteger eventID = new AtomicInteger(0);
    @Getter
    private final Map<Integer, Consumer<?>> returnCallbacks = new HashMap<>();

    public UISyncManager(ModularUI modularUI) {
        this.modularUI = modularUI;
    }

    public UISyncManager registerSyncValue(SyncValue<?> syncValue) {
        syncValues.add(syncValue);
        return this;
    }

    public UISyncManager unregisterSyncValue(SyncValue<?> syncValue) {
        syncValues.remove(syncValue);
        return this;
    }

    public UISyncManager registerRPCEvent(RPCEvent rpcEvent) {
        rpcEvents.add(rpcEvent);
        return this;
    }

    public UISyncManager unregisterRPCEvent(RPCEvent rpcEvent) {
        rpcEvents.remove(rpcEvent);
        return this;
    }


    /// Sync Data Logic
    public final void tick() {
        if (modularUI.player == null) return;
        var toSync = new ArrayList<SyncValue<?>>();
        for (var value : syncValues.values()) {
            value.update();
            if (value.hasChanged()) {
                toSync.add(value);
            }
        }
        if (toSync.isEmpty()) return;
        var data = ByteBufUtil.writeCustomData(buf -> {
            writePack(buf, toSync);
        });
        if (modularUI.player.level().isClientSide) {
            LDLNetworking.sendToServer(new PacketModularUISync(data));
        } else if (modularUI.player instanceof ServerPlayer serverPlayer) {
            LDLNetworking.sendToPlayer(serverPlayer, new PacketModularUISync(data));
        }
    }

    /**
     * Writes the opening snapshot, which rides the open-screen packet.
     *
     * <p>Only values this side is allowed to send are included, and the filter is load-bearing. A
     * value the receiver refuses — a C2S-only binding, on the way out to the client — is not merely
     * ignored on arrival: {@link SyncValue#readSyncData} throws <i>before</i> consuming the payload,
     * {@link #handlePack} swallows that and reads the next entry from the wrong offset, and the rest
     * of the pack is lost. Both sides derive the flag from the same pair of strategies, so filtering
     * here keeps their entry sets equal by construction. {@link #tick()} gets this for free, since
     * {@code hasChanged()} is already false whenever {@code toSync} is.
     */
    public void writeInitialData(FriendlyByteBuf buffer) {
        var toSync = new ArrayList<SyncValue<?>>();
        for (SyncValue<?> value : syncValues.values()) {
            value.update();
            if (value.isToSync()) {
                toSync.add(value);
            }
        }
        writePack(buffer, toSync);
    }

    public void readInitialData(FriendlyByteBuf data) {
        handlePack(data);
        // clear changed flag
        for (var value : syncValues.values()) {
            value.update();
            if (value.hasChanged()) {
                value.clearChanged();
            }
        }
    }

    public void handleSyncPacket(FriendlyByteBuf data) {
        handlePack(data);
    }

    private void writePack(FriendlyByteBuf buf, Collection<SyncValue<?>> syncValues) {
        buf.writeVarInt(syncValues.size());
        for (var syncValue : syncValues) {
            buf.writeVarInt(this.syncValues.getID(syncValue));
            syncValue.writeSyncData(buf);
            syncValue.clearChanged();
        }
    }

    private void handlePack(FriendlyByteBuf buf) {
        var size = buf.readVarInt();
        for (int i = 0; i < size; i++) {
            var id = buf.readVarInt();
            var syncValue = syncValues.getValue(id);
            if (syncValue != null) {
                try {
                    syncValue.readSyncData(buf);
                } catch (Exception e) {
                    LDLib2.LOGGER.warn("Note: This is an unexpected behavior, may be attacks by {}", modularUI.player, e);
                }
            } else {
                LDLib2.LOGGER.warn("Received sync data for unknown sync value with id {}", id);
            }
        }
    }

    /// Sync Event Logic
    private int nextEventID() {
        return eventID.getAndIncrement();
    }

    public void sendEvent(RPCEvent event, Object... args) {
        sendEvent(event, LDConsumers.nop(), args);
    }

    public <T> void sendEvent(RPCEvent event, Consumer<T> responseCallback, Object... args) {
        var player = modularUI.player;
        if (player == null) return;
        if (!rpcEvents.contains(event)) {
            LDLib2.LOGGER.warn("No UI RPC event registered for name {}", event);
            return;
        }

        var response = event.hasReturn() && responseCallback != null;
        int requestID;
        if (response) {
            requestID = nextEventID();
            returnCallbacks.put(requestID, responseCallback);
        } else {
            requestID = 0;
        }
        var data = ByteBufUtil.writeCustomData(buf -> {
            buf.writeVarInt(rpcEvents.getID(event));
            buf.writeBoolean(response);
            buf.writeVarInt(requestID);
            event.writeParametersToBuffer(buf, args);
        });
        if (player.level().isClientSide) {
            LDLNetworking.sendToServer(new PacketUIRPCEvent(data));
        } else if (player instanceof ServerPlayer serverPlayer) {
            LDLNetworking.sendToPlayer(serverPlayer, new PacketUIRPCEvent(data));
        }
    }

    public void handEvent(FriendlyByteBuf buf) {
        var player = modularUI.player;
        if (player == null) return;

        var eventID = buf.readVarInt();
        var response = buf.readBoolean();
        var requestID = buf.readVarInt();
        var rpcEvent = rpcEvents.getValue(eventID);
        if (rpcEvent == null) {
            LDLib2.LOGGER.warn("No UI RPC event registered for event {}, maybe attack?", eventID);
            return;
        }
        Object[] args;
        try {
            args = rpcEvent.readParametersFromBuffer(buf);
        } catch (Exception e) {
            LDLib2.LOGGER.warn("Could not handle ui rpc event {}. it may be attacks.", rpcEvent, e);
            return;
        }
        var returnValue = rpcEvent.executor().apply(args);
        if (response && rpcEvent.hasReturn()) {
            var data = ByteBufUtil.writeCustomData(returnBuf -> {
                returnBuf.writeVarInt(eventID);
                returnBuf.writeVarInt(requestID);
                rpcEvent.writeReturnValueToBuffer(returnBuf, returnValue);
            });
            if (player.level().isClientSide) {
                LDLNetworking.sendToServer(new PacketUIRPCEventReturn(data));
            } else if (player instanceof ServerPlayer serverPlayer) {
                LDLNetworking.sendToPlayer(serverPlayer, new PacketUIRPCEventReturn(data));
            }
        }
    }

    public void handEventReturn(FriendlyByteBuf buf) {
        var eventID = buf.readVarInt();
        var responseID = buf.readVarInt();
        var rpcEvent = rpcEvents.getValue(eventID);
        if (rpcEvent == null) {
            LDLib2.LOGGER.warn("No UI RPC event registered for event {}, maybe attack?", eventID);
            return;
        }
        if (rpcEvent.hasReturn() && returnCallbacks.containsKey(responseID)) {
            Consumer callback = returnCallbacks.remove(responseID);
            callback.accept(rpcEvent.readReturnValueFromBuffer(buf));
        }
    }

}
