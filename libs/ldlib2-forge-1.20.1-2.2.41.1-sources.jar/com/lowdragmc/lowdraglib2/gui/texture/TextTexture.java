package com.lowdragmc.lowdraglib2.gui.texture;

import com.lowdragmc.lowdraglib2.LDLib2;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigColor;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigNumber;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigSetter;
import com.lowdragmc.lowdraglib2.configurator.annotation.Configurable;
import com.lowdragmc.lowdraglib2.gui.LDLibFonts;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.GUIContext;
import com.lowdragmc.lowdraglib2.gui.util.DrawerHelper;
import com.lowdragmc.lowdraglib2.integration.kjs.KJSBindings;
import com.lowdragmc.lowdraglib2.registry.annotation.LDLRegisterClient;
import com.lowdragmc.lowdraglib2.utils.LocalizationUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import lombok.Setter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector4f;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@KJSBindings
@LDLRegisterClient(name = "text_texture", registry = "ldlib2:gui_texture")
public class TextTexture extends TransformTexture {

    @Configurable
    public String text;

    @Configurable
    @ConfigColor
    public int color;

    @Configurable
    @ConfigColor
    public int backgroundColor;

    @Configurable(tips = "ldlib.gui.editor.tips.image_text_width")
    @ConfigNumber(range = {1, Integer.MAX_VALUE})
    public int width;
    @Configurable
    @ConfigNumber(range = {0, Integer.MAX_VALUE})
    @Setter
    public float rollSpeed = 1;
    @Configurable
    public boolean dropShadow;

    @Configurable(tips = "ldlib.gui.editor.tips.image_text_type")
    public TextType type;

    public Supplier<String> supplier;
    @OnlyIn(Dist.CLIENT)
    private List<String> texts;

    private long lastTick;

    public TextTexture() {
        this("A", -1);
        setWidth(50);
    }

    public TextTexture(String text, int color) {
        this.color = color;
        this.type = TextType.NORMAL;
        if (LDLib2.isClient()) {
            this.text = LocalizationUtils.format(text);
            texts = Collections.singletonList(this.text);
        }
    }

    public TextTexture(String text) {
        this(text, -1);
        setDropShadow(true);
    }

    public TextTexture(Supplier<String> text) {
        this("", -1);
        setSupplier(text);
        setDropShadow(true);
    }

    public TextTexture setSupplier(Supplier<String> supplier) {
        this.supplier = supplier;
        return this;
    }

    @OnlyIn(Dist.CLIENT)
    public void updateTick() {
        if (Minecraft.getInstance().level != null) {
            long tick = Minecraft.getInstance().level.getGameTime();
            if (tick == lastTick) return;
            lastTick = tick;
            if (supplier != null) {
                updateText(supplier.get());
            }
        }
    }

    @ConfigSetter(field = "text")
    public void updateText(String text) {
        if (LDLib2.isClient()) {
            this.text = LocalizationUtils.format(text);
            texts = Collections.singletonList(this.text);
            setWidth(this.width);
        }
    }

    /**
     * A texture showing {@code text} exactly as given.
     *
     * <p>The constructors and {@link #updateText} treat their argument as a localisation key, which is
     * right for a hard-coded UI string and wrong for anything a user named. The lookup ends in a
     * {@link String#format}, so a file called {@code 50%_off.png} comes out as
     * {@code "Format error: 50%_off.png"}, and a name that happens to match a key any loaded mod
     * defines is replaced by that translation.
     */
    public static TextTexture raw(String text) {
        // Built empty and then filled in, because every constructor puts its argument through the
        // lookup. Otherwise identical to new TextTexture(text), drop shadow included.
        return new TextTexture("").setRawText(text);
    }

    /**
     * Replaces the text without a translation lookup.
     *
     * @see #raw(String)
     */
    public TextTexture setRawText(String text) {
        if (LDLib2.isClient()) {
            this.text = text;
            // Splits it against the current width, and fills in texts on the way.
            setWidth(this.width);
        }
        return this;
    }

    public TextTexture setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public TextTexture setColor(int color) {
        this.color = color;
        return this;
    }

    public TextTexture setDropShadow(boolean dropShadow) {
        this.dropShadow = dropShadow;
        return this;
    }

    public TextTexture setWidth(int width) {
        this.width = width;
        if (LDLib2.isClient()) {
            if (this.width > 0) {
                texts = LDLibFonts.font().getSplitter()
                        .splitLines(text, width, Style.EMPTY)
                        .stream().map(FormattedText::getString)
                        .collect(Collectors.toList());
                if (texts.isEmpty()) {
                    texts = Collections.singletonList(text);
                }
            } else {
                texts = Collections.singletonList(text);
            }
        }
        return this;
    }

    public TextTexture setType(TextType type) {
        this.type = type;
        return this;
    }

    @Override
    public TextTexture copy() {
        var copied = new TextTexture("", color);
        copied.type = type;
        copied.dropShadow = dropShadow;
        copied.rollSpeed = rollSpeed;
        copied.width = width;
        copied.backgroundColor = backgroundColor;
        // Raw, and last so it splits against the width just copied: this text has already been through
        // the lookup, and a second pass would mangle anything with a percent sign in it — which is
        // everything raw() exists to display.
        copied.setRawText(text);
        copied.copyTransform(this);
        return copied;
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    protected void drawInternal(GuiGraphics graphics, float mouseX, float mouseY, float x, float y, float width, float height, float partialTicks) {
        updateTick();
        if (backgroundColor != 0) {
            DrawerHelper.drawSolidRect(graphics, (int) x, (int) y, (int) width, (int) height, backgroundColor);
        }
        Font fontRenderer = LDLibFonts.font();
        int textH = fontRenderer.lineHeight;
        if (type == TextType.NORMAL) {
            textH *= texts.size();
            for (int i = 0; i < texts.size(); i++) {
                String line = texts.get(i);
                int lineWidth = fontRenderer.width(line);
                float _x = x + (width - lineWidth) / 2f;
                float _y = y + (height - textH) / 2f + i * fontRenderer.lineHeight;
                graphics.drawString(fontRenderer, line, (int) _x, (int) _y, color, dropShadow);
            }
        } else if (type == TextType.LEFT) {
            textH *= texts.size();
            for (int i = 0; i < texts.size(); i++) {
                String line = texts.get(i);
                float _y = y + (height - textH) / 2f + i * fontRenderer.lineHeight;
                graphics.drawString(fontRenderer, line, (int) x, (int) _y, color, dropShadow);
            }
        } else if (type == TextType.RIGHT) {
            textH *= texts.size();
            for (int i = 0; i < texts.size(); i++) {
                String line = texts.get(i);
                int lineWidth = fontRenderer.width(line);
                float _y = y + (height - textH) / 2f + i * fontRenderer.lineHeight;
                graphics.drawString(fontRenderer, line, (int) (x + width - lineWidth), (int) _y, color, dropShadow);
            }
        } else if (type == TextType.HIDE) {
            if (UIElement.isMouseOverRect((int) x, (int) y, (int) width, (int) height, mouseX, mouseY) && texts.size() > 1) {
                drawRollTextLine(graphics, x, y, width, height, fontRenderer, textH, text);
            } else {
                String line = texts.get(0) + (texts.size() > 1 ? ".." : "");
                drawTextLine(graphics, x, y, width, height, fontRenderer, textH, line);
            }
        } else if (type == TextType.ROLL || type == TextType.ROLL_ALWAYS) {
            if (texts.size() > 1 && (type == TextType.ROLL_ALWAYS || UIElement.isMouseOverRect((int) x, (int) y, (int) width, (int) height, mouseX, mouseY))) {
                drawRollTextLine(graphics, x, y, width, height, fontRenderer, textH, text);
            } else {
                drawTextLine(graphics, x, y, width, height, fontRenderer, textH, texts.get(0));
            }
        } else if (type == TextType.LEFT_HIDE) {
            if (UIElement.isMouseOverRect((int) x, (int) y, (int) width, (int) height, mouseX, mouseY) && texts.size() > 1) {
                drawRollTextLine(graphics, x, y, width, height, fontRenderer, textH, text);
            } else {
                String line = texts.get(0) + (texts.size() > 1 ? ".." : "");
                float _y = y + (height - textH) / 2f;
                graphics.drawString(fontRenderer, line, (int) x, (int) _y, color, dropShadow);
            }
        } else if (type == TextType.LEFT_ROLL || type == TextType.LEFT_ROLL_ALWAYS) {
            if (texts.size() > 1 && (type == TextType.LEFT_ROLL_ALWAYS || UIElement.isMouseOverRect((int) x, (int) y, (int) width, (int) height, mouseX, mouseY))) {
                drawRollTextLine(graphics, x, y, width, height, fontRenderer, textH, text);
            } else {
                float _y = y + (height - textH) / 2f;
                graphics.drawString(fontRenderer, texts.get(0), (int) x, (int) _y, color, dropShadow);
            }
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    /**
     * The context of the draw in progress, when there is one.
     *
     * <p>{@code drawInternal(GuiGraphics, ...)} is the abstract method this class has to implement,
     * so the context cannot be a parameter. It is only read by {@link #drawRollTextLine}, which needs
     * a clip rectangle and would otherwise have to guess which surface it is drawing into.
     */
    @Nullable
    @OnlyIn(Dist.CLIENT)
    private transient GUIContext context;

    @Override
    @OnlyIn(Dist.CLIENT)
    protected void drawInternal(GUIContext context, float x, float y, float width, float height) {
        this.context = context;
        try {
            super.drawInternal(context, x, y, width, height);
        } finally {
            this.context = null;
        }
    }

    @OnlyIn(Dist.CLIENT)
    private void drawRollTextLine(GuiGraphics graphics, float x, float y, float width, float height, Font fontRenderer, int textH, String line) {
        float _y = y + (height - textH) / 2f;
        float textW = fontRenderer.width(line);
        float totalW = width + textW + 10;
        float from = x + width;
        var trans = graphics.pose().last().pose();
        var realPos = trans.transform(new Vector4f(x, y, 0, 1));
        var realPos2 = trans.transform(new Vector4f(x + width, y + height, 0, 1));
        // Prefer the context: it clips against the surface actually being drawn into, and intersects
        // with the enclosing clip. GuiGraphics' own scissor flips against the *game window*, so it is
        // only correct when that is where this is going — which is the fallback case below.
        var context = this.context;
        if (context != null) {
            context.enableScissor(x, y, width, height);
        } else {
            graphics.enableScissor((int) realPos.x, (int) realPos.y, (int) realPos2.x, (int) realPos2.y);
        }
        var t = rollSpeed > 0 ? ((((rollSpeed * Math.abs((int)(System.currentTimeMillis() % 1000000)) / 10) % (totalW))) / (totalW)) : 0.5;
        graphics.drawString(fontRenderer, line, (int) (from - t * totalW), (int) _y, color, dropShadow);
        if (context != null) {
            context.disableScissor();
        } else {
            graphics.disableScissor();
        }
    }

    @OnlyIn(Dist.CLIENT)
    private void drawTextLine(GuiGraphics graphics, float x, float y, float width, float height, Font fontRenderer, int textH, String line) {
        int textW = fontRenderer.width(line);
        float _x = x + (width - textW) / 2f;
        float _y = y + (height - textH) / 2f;
        graphics.drawString(fontRenderer, line, (int) _x, (int) _y, color, dropShadow);
    }

    @OnlyIn(Dist.CLIENT)
    public int getLines() {
        return texts.size();
    }

    public enum TextType{
        NORMAL,
        HIDE,
        ROLL,
        ROLL_ALWAYS,
        LEFT,
        RIGHT,
        LEFT_HIDE,
        LEFT_ROLL,
        LEFT_ROLL_ALWAYS
    }
}
