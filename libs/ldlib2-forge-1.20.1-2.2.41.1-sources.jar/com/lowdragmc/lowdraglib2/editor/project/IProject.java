package com.lowdragmc.lowdraglib2.editor.project;

import com.lowdragmc.lowdraglib2.Platform;
import com.lowdragmc.lowdraglib2.editor.resource.Resources;
import com.lowdragmc.lowdraglib2.editor.ui.Editor;
import com.lowdragmc.lowdraglib2.gui.texture.IGuiTexture;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.util.INBTSerializable;

import javax.annotation.Nonnull;

/**
 * Interface for a project in the editor.
 */
public interface IProject extends INBTSerializable<CompoundTag> {
    /**
     * Get Resources of this project
     */
    Resources getResources();

    /**
     * Get the type of this project.
     */
    ProjectType getProjectType();

    /**
     * Get the file suffix for this project. It will be used to save the project file or load it.
     */
    default String getSuffix() {
        return getProjectType().getSuffix();
    }

    /**
     * Get the name of this project.
     */
    default String getName() {
        return getProjectType().getName();
    }

    /**
     * Serialize the project to NBT.
     * This method will be called when saving the project.
     */
    CompoundTag serializeProject(@Nonnull HolderLookup.Provider provider);

    /**
     * Deserialize the project from NBT.
     */
    void deserializeProject(@Nonnull HolderLookup.Provider provider, @Nonnull CompoundTag nbt);

    /**
     * Get the display name of this project.
     */
    default Component getDisplayName() {
        return Component.translatable(getName());
    }

    /**
     * Get the icon of this project. Defaults to the icon of its {@link ProjectType}, which itself falls
     * back to {@link ProjectType#getDefaultIcon()} when the type does not set one.
     */
    default IGuiTexture getIcon() {
        return getProjectType().getIcon();
    }

    /**
     * Initialize a new empty project. This method will be called when creating a new project and before {@link #onLoad(Editor)}.
     */
    default void initNewProject() {
    }

    /**
     * Fired when the project is closed
     */
    default void onClosed(Editor editor) {
    }

    /**
     * Fired when the project is opened.
     *
     * <p>The place to add whatever this project brings to the editor, shortcuts included:
     * <pre>{@code
     * public void onLoad(Editor editor) {
     *     actions = editor.getKeymap().registerAll(
     *             EditorAction.builder(MyIds.RUN)
     *                     .category(KeymapCategories.GENERAL)
     *                     .defaultChord(KeyChord.key(GLFW.GLFW_KEY_F5))
     *                     .when(KeyContext.focusWithin(MyView.class))
     *                     .onAction(this::run)
     *                     .build());
     * }
     *
     * public void onClosed(Editor editor) {
     *     actions.unsubscribe();   // the editor outlives the project
     * }
     * }</pre>
     *
     * Anything registered shows up in the keymap settings and can be rebound like a built-in action.
     */
    default void onLoad(Editor editor) {
    }

    /**
     * Get the version of this project.
     * Default version, can be overridden by specific projects.
     * It will be stored in the project file.
     */
    default String getVersion() {
        return "1.0";
    }

    /**
     * Get metadata of this project. e.g. version, suffix, name.
     */
    default CompoundTag getMetadata() {
        var data = new CompoundTag();
        data.putString("version", getVersion());
        data.putString("suffix", getSuffix());
        data.putString("name", getName());
        return data;
    }

    @Override
    default CompoundTag serializeNBT() {
        return serializeNBT(Platform.getFrozenRegistry());
    }

    default CompoundTag serializeNBT(@Nonnull HolderLookup.Provider provider) {
        var data = new CompoundTag();
        data.put("meta", getMetadata());
        data.put("data", serializeProject(provider));
        return data;
    }

    @Override
    default void deserializeNBT(@Nonnull CompoundTag nbt) {
        deserializeNBT(Platform.getFrozenRegistry(), nbt);
    }

    default void deserializeNBT(@Nonnull HolderLookup.Provider provider, @Nonnull CompoundTag nbt) {
        deserializeProject(provider, nbt.getCompound("data"));
    }
}
