package com.lowdragmc.lowdraglib2.editor.settings;

import com.lowdragmc.lowdraglib2.LDLib2;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigSearch;
import com.lowdragmc.lowdraglib2.configurator.annotation.Configurable;
import com.lowdragmc.lowdraglib2.configurator.ui.ConfiguratorGroup;
import com.lowdragmc.lowdraglib2.configurator.ui.SearchComponentConfigurator;
import com.lowdragmc.lowdraglib2.configurator.ui.SelectorConfigurator;
import com.lowdragmc.lowdraglib2.editor.ui.Editor;
import com.lowdragmc.lowdraglib2.gui.ui.ModularUI;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvent;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEventListener;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.OffscreenSurface;
import com.lowdragmc.lowdraglib2.gui.ui.style.Stylesheet;
import com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager;
import com.lowdragmc.lowdraglib2.gui.ui.utils.UIElementProvider;
import com.lowdragmc.lowdraglib2.gui.ui.window.WindowBounds;
import com.lowdragmc.lowdraglib2.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib2.utils.PersistedParser;
import com.lowdragmc.lowdraglib2.utils.search.IResultHandler;
import com.mojang.serialization.Codec;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Optional;

public class AppearanceSettings implements Settings {
    public static final ResourceLocation ID = LDLib2.id("appearance");
    public static final Codec<AppearanceSettings> CODEC = PersistedParser.createCodec(AppearanceSettings::new);

    @Configurable
    @ConfigSearch(searchConfiguratorMethod = "searchStyles")
    @Getter @Setter
    private ResourceLocation stylesheet = StylesheetManager.ORE_MERGED;
    @Persisted(key = "windowSize")
    @Getter @Setter
    private int screenScale = -1;
    /**
     * Whether this editor opens in a window of its own rather than as a screen in the game window.
     * Off by default; the title bar's toggle writes it too, so moving the editor once is remembered.
     */
    @Configurable(name = "settings.ldlib2.appearance.preferOsWindow",
            tips = "settings.ldlib2.appearance.preferOsWindow.tips")
    @Persisted(key = "preferOsWindow")
    @Getter @Setter
    private boolean preferOsWindow = false;
    /** Where that window was last left. Four ints so an older settings file still loads. */
    @Persisted(key = "editorWindowX")
    private int editorWindowX = Integer.MIN_VALUE;
    @Persisted(key = "editorWindowY")
    private int editorWindowY = Integer.MIN_VALUE;
    @Persisted(key = "editorWindowWidth")
    private int editorWindowWidth;
    @Persisted(key = "editorWindowHeight")
    private int editorWindowHeight;

    // runtime
    @Nullable
    private Stylesheet currentStylesheet;
    @Nullable
    private WeakReference<ModularUI> appliedModularUI;
    @Nullable
    private WeakReference<Editor> appliedEditor;
    private final UIEventListener onMuiChangedListener = this::onModularUIChanged;

    /** The appearance settings of an editor, or empty when it has none registered. */
    public static Optional<AppearanceSettings> of(Editor editor) {
        return editor.getEditorSettings().getSettings(ID)
                .filter(AppearanceSettings.class::isInstance)
                .map(AppearanceSettings.class::cast);
    }

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    /** The remembered window rectangle, or null if there is not one yet. */
    @Nullable
    public WindowBounds getEditorWindowBounds() {
        if (editorWindowWidth <= 0 || editorWindowHeight <= 0) return null;
        return new WindowBounds(editorWindowX, editorWindowY, editorWindowWidth, editorWindowHeight);
    }

    public void setEditorWindowBounds(WindowBounds bounds) {
        editorWindowX = bounds.x();
        editorWindowY = bounds.y();
        editorWindowWidth = bounds.width();
        editorWindowHeight = bounds.height();
    }

    @Override
    public String getPath() {
        return "Appearance";
    }

    @Override
    public void onApply(Editor editor) {
        if (!editor.hasEventListener(UIEvents.MUI_CHANGED, onMuiChangedListener)) {
            editor.addEventListener(UIEvents.MUI_CHANGED, onMuiChangedListener);
        }
        appliedEditor = new WeakReference<>(editor);
        applyStylesheet(editor);
        applyPreferredHost(editor);
        applyScreenScale(editor);
    }

    /**
     * Applies {@link #screenScale} to wherever the editor is shown: its own window's scale when it is
     * in one, which leaves the game alone, or else the game's gui scale.
     */
    private void applyScreenScale(Editor editor) {
        var window = editor.getWindow();
        if (window != null && window.isInOsWindow()) {
            window.getOsWindow().setGuiScale(screenScale);
            return;
        }
        // -1 means the player never picked an editor-specific scale, so their own GUI scale stands.
        // Without this the value would reach options#guiScale, be clamped to 0, and silently switch
        // the game to "auto" the first time any editor is created.
        if (screenScale < 0) return;
        var minecraft = Minecraft.getInstance();
        var guiScale = minecraft.options.guiScale();
        var maxScale =  minecraft.getWindow().calculateScale(0, minecraft.isEnforceUnicode());
        if (screenScale > maxScale) {
            screenScale = maxScale;
        }
        if (guiScale.get() != screenScale) {
            guiScale.set(screenScale);
            Minecraft.getInstance().resizeDisplay();
        }
    }

    /**
     * Moves the editor to the host this setting asks for.
     *
     * <p>Only once it is actually being shown: {@code onApply} also runs while the editor is being
     * built, and re-hosting a tree that has not been hosted yet has nowhere to move it from.
     */
    private void applyPreferredHost(Editor editor) {
        var window = editor.getWindow();
        if (window == null || editor.getModularUI() == null) return;
        if (preferOsWindow) {
            window.popOutToOsWindow();
        } else if (window.isInOsWindow()) {
            window.dockIntoGameWindow();
        }
    }

    private void onModularUIChanged(UIEvent event) {
        if (event.currentElement instanceof Editor editor) {
            applyStylesheet(editor);
        }
    }

    private void applyStylesheet(Editor editor) {
        var stylesheet = StylesheetManager.INSTANCE.getStylesheet(this.stylesheet);
        if (stylesheet == null) {
            return;
        }

        var mui = editor.getModularUI();
        if (mui == null) {
            appliedModularUI = null;
            currentStylesheet = stylesheet;
            return;
        }

        var previousMui = appliedModularUI == null ? null : appliedModularUI.get();
        if (previousMui == mui && currentStylesheet == stylesheet) {
            return;
        }

        if (previousMui != null && currentStylesheet != null) {
            previousMui.getStyleEngine().removeStylesheet(currentStylesheet);
        }
        mui.getStyleEngine().addStylesheet(stylesheet);
        appliedModularUI = new WeakReference<>(mui);
        currentStylesheet = stylesheet;
    }

    private SearchComponentConfigurator.ISearchConfigurator<ResourceLocation> searchStyles() {
        return new SearchComponentConfigurator.ISearchConfigurator<>() {
            @Override
            @Nonnull
            public ResourceLocation defaultValue() {
                return StylesheetManager.ORE_MERGED;
            }

            @Override
            public void search(String word, IResultHandler<ResourceLocation> searchHandler) {
                var lowerWord = word.toLowerCase();
                for (var key : StylesheetManager.INSTANCE.getAllPackStylesheets()) {
                    if (Thread.currentThread().isInterrupted()) return;
                    if (key.toString().toLowerCase().contains(lowerWord)) {
                        if (key.getPath().endsWith(StylesheetManager.PATH)) {
                            key = key.withPath(key.getPath().substring(0, key.getPath().length() - StylesheetManager.PATH.length() - 1));
                        }
                        searchHandler.acceptResult(key);
                    }
                }
            }

            @Override
            @Nonnull
            public String resultText(@NotNull ResourceLocation value) {
                return value.toString();
            }

            @Override
            public UIElementProvider<ResourceLocation> candidateUIProvider() {
                return UIElementProvider.text(res -> Component.literal(res.toString()));
            }
        };
    }

    @Override
    public void buildConfigurator(ConfiguratorGroup father) {
        Settings.super.buildConfigurator(father);
        // scale
        var editor = appliedEditor == null ? null : appliedEditor.get();
        var osWindow = editor == null || editor.getWindow() == null || !editor.getWindow().isInOsWindow()
                ? null : editor.getWindow().getOsWindow();
        var minecraft = Minecraft.getInstance();
        var maxScale = osWindow != null
                ? Math.max(osWindow.getMaxGuiScale(), screenScale)
                : minecraft.getWindow().calculateScale(0, minecraft.isEnforceUnicode());
        var scales = new ArrayList<Integer>(maxScale + 2);
        if (osWindow != null) {
            scales.add(OffscreenSurface.FOLLOW_GAME);
        }
        for (int i = 0; i <= maxScale; i++) {
            scales.add(i);
        }
        father.addConfiguratorAt(new SelectorConfigurator<>("ldlib.gui.editor.menu.view.window_size", () -> screenScale, scale -> {
            setScreenScale(scale);
            if (editor != null) {
                applyScreenScale(editor);
            } else {
                minecraft.options.guiScale().set(scale);
            }
        }, -1, true, scales, scale -> scale < 0 ? "editor.window.scale.follow_game"
                : scale == 0 ? "options.guiScale.auto" : scale + ""), 1);
    }
}
