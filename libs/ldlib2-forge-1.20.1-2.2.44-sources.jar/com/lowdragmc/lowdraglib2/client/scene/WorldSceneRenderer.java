package com.lowdragmc.lowdraglib2.client.scene;

import com.lowdragmc.lowdraglib2.client.RenderTargetScope;
import com.lowdragmc.lowdraglib2.client.shader.management.ShaderManager;
import com.lowdragmc.lowdraglib2.client.utils.glu.Project;
import com.lowdragmc.lowdraglib2.math.Position;
import com.lowdragmc.lowdraglib2.math.PositionedRect;
import com.lowdragmc.lowdraglib2.math.Size;
import com.lowdragmc.lowdraglib2.utils.virtuallevel.DummyWorld;
import com.lowdragmc.lowdraglib2.utils.virtuallevel.TrackedDummyWorld;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

import javax.annotation.Nonnull;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import static net.minecraft.world.level.block.RenderShape.INVISIBLE;


/**
 * @author KilaBash
 * @date 2022/05/25
 * @implNote render a scene, through VBO compilation scene, greatly optimize rendering performance.
 */
@OnlyIn(Dist.CLIENT)
@Accessors(chain = true)
public abstract class WorldSceneRenderer {
    protected static final FloatBuffer MODELVIEW_MATRIX_BUFFER = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    protected static final FloatBuffer PROJECTION_MATRIX_BUFFER = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    protected static final IntBuffer VIEWPORT_BUFFER = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
    protected static final FloatBuffer PIXEL_DEPTH_BUFFER = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    protected static final FloatBuffer OBJECT_POS_BUFFER = ByteBuffer.allocateDirect(3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();

    /**
     * Where drawing was going when {@link #setupCamera} took over, so {@link #resetCamera} can put it
     * back. Null outside a camera pass.
     */
    @Nullable
    private RenderTargetScope cameraScope;

    enum CacheState {
        UNCREATED,
        NEED,
        COMPILING,
        COMPILED
    }

    public final Level world;
    /**
     * Identity-keyed map: the caller's {@link Collection} reference is the handle used by
     * {@link #removeRenderedBlocks(Collection)}, while {@link RenderedBlocksEntry#snapshot} holds an
     * immutable copy that the (possibly background) compile and render code iterates safely.
     */
    public final Map<Collection<BlockPos>, RenderedBlocksEntry> renderedBlocksMap;

    public record RenderedBlocksEntry(Set<BlockPos> snapshot, @Nullable ISceneBlockRenderHook hook) {
    }

    @Nullable
    protected VertexBuffer[] vertexBuffers;
    @Nullable
    protected boolean[] vertexBuffersUsingMark;
    protected Set<BlockPos> tileEntities;
    @Getter
    protected boolean useCache;
    /**
     * When {@link #useCache} is on, prefer running the cache compile on the main/render thread,
     * spread across multiple frames, instead of on a background thread. Useful when the backing
     * {@link Level} doesn't support off-thread access.
     */
    @Getter
    protected boolean syncCompile;
    /**
     * Per-frame time budget for {@link #syncCompile} mode, in nanoseconds. Default 2ms.
     * The compile loop always processes at least one block per frame to make forward progress.
     */
    @Getter
    @Setter
    protected long syncCompileTimeBudgetNanos = 2_000_000L;
    /**
     * Hard cap on blocks processed per frame in {@link #syncCompile} mode. Acts as a safety net
     * when individual blocks render extremely fast.
     */
    @Getter
    @Setter
    protected int syncCompileMaxBlocksPerFrame = 200;
    @Nullable
    protected SyncCompileState syncCompileState;
    @Getter
    @Setter
    protected boolean endBatchLast = false;// if true, endBatch will be called after all rendering
    @Getter
    protected boolean ortho;
    protected AtomicReference<CacheState> cacheState;
    protected int maxProgress;
    protected int progress;
    protected Thread thread;
    @Getter
    protected ParticleManager particleManager;
    protected final Camera camera = new Camera();
    protected final CameraEntity cameraEntity;
    @Setter
    protected ClipContext.Block clipBlock = ClipContext.Block.OUTLINE;
    @Setter
    protected ClipContext.Fluid clipFluid = ClipContext.Fluid.NONE;
    @Setter
    @Nullable
    private Consumer<WorldSceneRenderer> beforeWorldRender;
    @Setter
    @Nullable
    private Consumer<WorldSceneRenderer> afterWorldRender;
    @Setter
    @Nullable
    private BiConsumer<MultiBufferSource, Float> beforeBatchEnd;
    @Setter
    @Nullable
    private Consumer<BlockHitResult> onLookingAt;
    @Setter
    @Nullable
    private ISceneEntityRenderHook sceneEntityRenderHook;
    @Getter
    private Vector3f lastHit;
    @Getter
    private BlockHitResult lastTraceResult;
    @Setter
    private Set<BlockPos> blocked;
    @Getter
    private Vector3f eyePos = new Vector3f(0, 0, 10f);
    @Getter
    private Vector3f lookAt = new Vector3f(0, 0, 0);
    @Getter
    private Vector3f worldUp = new Vector3f(0, 1, 0);
    @Getter
    @Setter
    private float fov = 60f;
    private float minX, maxX, minY, maxY, minZ, maxZ;
    /**
     * The viewport aspect ratio {@link #setupCamera} last built the projection with. Kept because only
     * the projection knows it — it comes from the viewport rather than from any camera setting — and
     * {@link #getViewHalfHeight} cannot answer for an orthographic camera without it.
     */
    private float lastAspectRatio = 1f;

    public WorldSceneRenderer(Level world) {
        this.world = world;
        renderedBlocksMap = new IdentityHashMap<>();
        cacheState = new AtomicReference<>(CacheState.UNCREATED);
        cameraEntity = new CameraEntity(world);
    }

    /**
     * Release all resources used by this renderer. this should be called in the render thread.
     */
    public void releaseResource() {
        deleteCacheBuffer();
    }

    public WorldSceneRenderer setParticleManager(ParticleManager particleManager) {
        this.particleManager = particleManager;
        if (this.world instanceof DummyWorld dummyWorld) {
            dummyWorld.setParticleManager(particleManager);
        }
        setCameraLookAt(eyePos, lookAt, worldUp);
        return this;
    }

    public WorldSceneRenderer useCacheBuffer(boolean useCache) {
        if (this.useCache || !Minecraft.getInstance().isSameThread()) return this;
        this.useCache = useCache;
        if (!useCache) {
            deleteCacheBuffer();
        }
        return this;
    }

    /**
     * Toggle the incremental main-thread cache compile path. Triggers a recompile so the new
     * mode takes effect on the next render.
     */
    public WorldSceneRenderer syncCompile(boolean syncCompile) {
        if (this.syncCompile == syncCompile) return this;
        this.syncCompile = syncCompile;
        needCompileCache();
        return this;
    }

    /**
     * Per-frame, incrementally advanced state for sync-compile mode. Lives only while a sync
     * compile is in flight; cleared by {@link #cancelCompile()} and replaced on next compile.
     */
    protected static class SyncCompileState {
        final List<RenderType> layers;
        final List<RenderedBlocksEntry> entries;
        final PoseStack matrixStack = new PoseStack();
        final RandomSource randomSource = RandomSource.createNewThreadLocalInstance();
        // block phase
        int layerIndex = 0;
        @Nullable BufferBuilder currentBuffer;
        int entryIndex = 0;
        @Nullable Iterator<BlockPos> blockIter;
        // tile-entity scan phase
        boolean tilePhase = false;
        int tileEntryIndex = 0;
        @Nullable Iterator<BlockPos> tileBlockIter;
        final Set<BlockPos> collectedTiles = new HashSet<>();

        SyncCompileState(List<RenderType> layers, List<RenderedBlocksEntry> entries) {
            this.layers = layers;
            this.entries = entries;
        }
    }

    public WorldSceneRenderer useOrtho(boolean ortho) {
        this.ortho = ortho;
        return this;
    }

    public WorldSceneRenderer deleteCacheBuffer() {
        if (vertexBuffers != null) {
            for (int i = 0; i < RenderType.chunkBufferLayers().size(); ++i) {
                if (this.vertexBuffers[i] != null) {
                    this.vertexBuffers[i].close();
                }
            }
            cancelCompile();
            this.vertexBuffers = null;
            this.vertexBuffersUsingMark = null;
        }
        this.tileEntities = null;
        cacheState.set(CacheState.UNCREATED);
        return this;
    }

    protected void makeSureCacheBufferCreated() {
        if (vertexBuffers == null) {
            List<RenderType> layers = RenderType.chunkBufferLayers();
            this.vertexBuffers = new VertexBuffer[layers.size()];
            this.vertexBuffersUsingMark = new boolean[layers.size()];
            for (int j = 0; j < layers.size(); ++j) {
                this.vertexBuffers[j] = new VertexBuffer(VertexBuffer.Usage.STATIC);
            }
            cancelCompile();
            cacheState.set(CacheState.NEED);
        }
    }

    public WorldSceneRenderer needCompileCache() {
        cancelCompile();
        cacheState.set(CacheState.NEED);
        return this;
    }

    /**
     * Cancels any in-flight compile, whether async (background thread) or sync (cursor on main thread).
     * For async, interrupts and joins the thread briefly so subsequent map mutations cannot race
     * with an in-flight iteration of {@link #renderedBlocksMap}.
     */
    private void cancelCompile() {
        var t = thread;
        if (t != null) {
            thread = null;
            t.interrupt();
            try {
                t.join(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        // Discard any in-flight sync cursor; the partially-filled BufferBuilder is dropped
        // (its underlying ByteBuffer will be GC'd along with the state object).
        if (syncCompileState != null && syncCompileState.currentBuffer != null) {
            try {
                syncCompileState.currentBuffer.discard();
            } catch (Throwable ignored) {
            }
        }
        syncCompileState = null;
    }

    public WorldSceneRenderer addRenderedBlocks(Collection<BlockPos> blocks, @Nullable ISceneBlockRenderHook renderHook) {
        if (blocks != null) {
            cancelCompile();
            // Snapshot so later mutations to the caller's collection don't race with the compile thread.
            this.renderedBlocksMap.put(blocks, new RenderedBlocksEntry(Set.copyOf(blocks), renderHook));
        }
        return this;
    }

    public WorldSceneRenderer removeRenderedBlocks(Collection<BlockPos> blocks) {
        if (blocks != null) {
            cancelCompile();
            this.renderedBlocksMap.remove(blocks);
        }
        return this;
    }

    public WorldSceneRenderer removeAllRenderedBlocks() {
        cancelCompile();
        this.renderedBlocksMap.clear();
        return this;
    }

    /**
     * Draws whatever the GUI has queued up before this scene takes over the render state.
     * <p>
     * A scene shares {@code renderBuffers().bufferSource()} with {@link net.minecraft.client.gui.GuiGraphics},
     * and {@link #drawWorld()} calls the argument-less {@code endBatch()}, which flushes EVERY pending
     * render type — including GUI geometry recorded earlier in the frame. Without this, that geometry
     * would be drawn with the scene's viewport and 3D matrices instead of the screen's, so it would
     * silently vanish. Callers must invoke this before they touch the render state, which for a render
     * target means before binding it, or the flushed geometry lands in the target.
     */
    protected static void flushPendingGuiBatches() {
        Minecraft.getInstance().renderBuffers().bufferSource().endBatch();
    }

    public void render(@Nonnull PoseStack poseStack, float x, float y, float width, float height, int mouseX, int mouseY) {
        // do not render if the minecraft is reloading
        if (Minecraft.getInstance().getOverlay() instanceof LoadingOverlay) {
            return;
        }
        flushPendingGuiBatches();
        // setupCamera
        var pose = poseStack.last().pose();
        Vector4f pos = new Vector4f(x, y, 0, 1.0F);
        pos = pose.transform(pos);
        Vector4f size = new Vector4f(x + width, y + height, 0, 1.0F);
        size = pose.transform(size);
        x = pos.x();
        y = pos.y();
        width = size.x() - x;
        height = size.y() - y;
        PositionedRect viewport = getPositionedRect((int) x, (int) y, (int) width, (int) height);
        var topLeft = poseStack.last().pose().transformPosition(new Vector3f(0.0f, 0.0f, 0.0f));
        PositionedRect mouse = getPositionedRect((int) (mouseX + topLeft.x), (int) (mouseY + topLeft.y), 0, 0);
        mouseX = mouse.position.x;
        mouseY = mouse.position.y;
        setupCamera(viewport);
        // render TrackedDummyWorld
        drawWorld();
        // check lookingAt
        this.lastTraceResult = null;
        this.lastHit = unProject(mouseX, mouseY);
        if (onLookingAt != null && mouseX > viewport.position.x && mouseX < viewport.position.x + viewport.size.width
                && mouseY > viewport.position.y && mouseY < viewport.position.y + viewport.size.height) {
            BlockHitResult result = rayTrace(lastHit);
            if (result != null) {
                this.lastTraceResult = null;
                this.lastTraceResult = result;
                onLookingAt.accept(result);
            }
        }
        // resetCamera
        resetCamera();
    }

    public void setCameraLookAt(Vector3f eyePos, Vector3f lookAt, Vector3f worldUp) {
        this.eyePos = eyePos;
        this.lookAt = lookAt;
        this.worldUp = worldUp;
        Vector3f xzProduct = new Vector3f(lookAt.x() - eyePos.x(), 0, lookAt.z() - eyePos.z());
        double angleYaw = Math.toDegrees(xzProduct.angle(new Vector3f(0, 0, 1)));
        if (xzProduct.angle(new Vector3f(1, 0, 0)) < Math.PI / 2) {
            angleYaw = -angleYaw;
        }
        double anglePitch = Math.toDegrees(new Vector3f(lookAt).sub(new Vector3f(eyePos)).angle(new Vector3f(0, 1, 0))) - 90;
        cameraEntity.setPos(eyePos.x(), eyePos.y(), eyePos.z());
        cameraEntity.xo = cameraEntity.getX();
        cameraEntity.yo = cameraEntity.getY();
        cameraEntity.zo = cameraEntity.getZ();
        cameraEntity.setYRot((float) angleYaw);
        cameraEntity.setXRot((float) anglePitch);
        cameraEntity.yRotO = cameraEntity.getYRot();
        cameraEntity.xRotO = cameraEntity.getXRot();
    }

    public void setCameraLookAt(Vector3f lookAt, double radius, double yaw, double pitch) {
        Vector3f vecX = new Vector3f((float) Math.cos(yaw), (float) 0, (float) Math.sin(yaw));
        Vector3f vecY = new Vector3f(0, (float) (Math.tan(pitch) * vecX.length()), 0);
        Vector3f pos = new Vector3f(vecX).add(vecY).normalize().mul((float) radius);
        setCameraLookAt(pos.add(lookAt.x(), lookAt.y(), lookAt.z()), lookAt, worldUp);
    }

    public void setCameraOrtho(float x, float y, float z) {
        this.minX = -x;
        this.maxX = x;
        this.minY = -y;
        this.maxY = y;
        this.minZ = -z;
        this.maxZ = z;
    }

    public void setCameraOrtho(float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
        this.minX = minX;
        this.maxX = maxX;
        this.minY = minY;
        this.maxY = maxY;
        this.minZ = minZ;
        this.maxZ = maxZ;
    }

    /**
     * Half the world-space height the viewport spans {@code distance} in front of the eye — the length
     * that fills half the view vertically, and so the unit for anything that wants to keep a constant
     * size on screen.
     *
     * <p>⚠️ The distance is <b>ignored</b> under an orthographic camera, where it genuinely changes
     * nothing: that projection has no foreshortening, so the answer is the ortho box's own height however
     * far away the thing being measured is. Working out {@code distance * tan(fov / 2)} at the call site
     * instead is right in perspective and badly wrong here — {@link #getEyePos()} in ortho is usually
     * parked a fraction of a block from what it looks at, because nothing about the picture depends on
     * where along the view direction it sits, and a caller scaling by that gets something invisible.
     */
    public float getViewHalfHeight(float distance) {
        if (ortho) {
            // matching setupCamera, which divides the vertical ortho bounds by the aspect ratio
            return (maxY - minY) * 0.5f / lastAspectRatio;
        }
        return distance * (float) Math.tan(fov * 0.5f * Math.PI / 180);
    }

    public PositionedRect getPositionedRect(int x, int y, int width, int height) {
        return PositionedRect.of(Position.of(x, y), Size.of(width, height));
    }

    public PositionedRect getPositionRectRevert(int windowX, int windowY, int windowWidth, int windowHeight) {
        return PositionedRect.of(Position.of(windowX, windowY), Size.of(windowWidth, windowHeight));
    }

    protected void setupCamera(PositionedRect viewport) {
        // Captured before the viewport is replaced, so resetCamera can put back what was actually
        // there. The scene may be nested inside a UI visual layer, or inside a UI hosted in another
        // window; in neither case is the game's main frame the right thing to return to.
        cameraScope = RenderTargetScope.capture();
        int x = viewport.getPosition().x;
        int y = viewport.getPosition().y;
        int width = viewport.getSize().width;
        int height = viewport.getSize().height;

        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();

        //setup viewport and clear GL buffers
        RenderSystem.viewport(x, y, width, height);

        RenderSystem.depthMask(true);
        clearView(x, y, width, height);

        //setup projection matrix to perspective
        RenderSystem.backupProjectionMatrix();

        Minecraft mc = Minecraft.getInstance();
        float aspectRatio = width / (height * 1.0f);
        if (Float.isFinite(aspectRatio) && aspectRatio > 0) {
            this.lastAspectRatio = aspectRatio;
        }
        camera.setup(world, cameraEntity, false, false, mc.getPartialTick());
        if (ortho) {
            RenderSystem.setProjectionMatrix(new Matrix4f().setOrtho(minX, maxX, minY / aspectRatio, maxY / aspectRatio, minZ, maxZ), VertexSorting.byDistance(camera.getPosition().toVector3f()));
        } else {
            RenderSystem.setProjectionMatrix(new Matrix4f().setPerspective(fov * 0.01745329238474369F, aspectRatio, 0.1f, 10000.0f), VertexSorting.byDistance(camera.getPosition().toVector3f()));
        }

        //setup model view matrix
        PoseStack posesStack = RenderSystem.getModelViewStack();
        posesStack.pushPose();
        posesStack.setIdentity();
        posesStack.mulPoseMatrix(new Matrix4f().lookAt(eyePos.x(), eyePos.y(), eyePos.z(), lookAt.x(), lookAt.y(), lookAt.z(), worldUp.x(), worldUp.y(), worldUp.z()));
        RenderSystem.applyModelViewMatrix();

        RenderSystem.activeTexture(org.lwjgl.opengl.GL13.GL_TEXTURE0);

        RenderSystem.enableCull();

        ShaderManager.getInstance().setViewPort(viewport);

    }

    protected void clearView(int x, int y, int width, int height) {
        RenderSystem.clearColor(0, 0, 0, 0);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
    }

    protected void resetCamera() {
        //reset viewport
        if (cameraScope != null) {
            cameraScope.close();
            cameraScope = null;
        }

        //reset projection matrix
        RenderSystem.restoreProjectionMatrix();

        //reset modelview matrix
        PoseStack posesStack = RenderSystem.getModelViewStack();
        posesStack.popPose();
        RenderSystem.applyModelViewMatrix();

//        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        ShaderManager.getInstance().clearViewPort();
    }

    protected void drawWorld() {
        if (beforeWorldRender != null) {
            beforeWorldRender.accept(this);
        }

        Minecraft mc = Minecraft.getInstance();

        float particleTicks = mc.getPartialTick();
        var buffers = mc.renderBuffers().bufferSource();
        if (useCache) {
            renderCacheBuffer(mc, buffers, particleTicks);
        } else {
            var bsr = mc.getBlockRenderer();
            var randomSource = RandomSource.createNewThreadLocalInstance();
            // render the blocks in each layer
            renderedBlocksMap.forEach((key, entry) -> {
                var renderedBlocks = entry.snapshot();
                var hook = entry.hook();
                for (RenderType layer : RenderType.chunkBufferLayers()) {
                    layer.setupRenderState();
                    PoseStack poseStack = new PoseStack();

                    if (layer == RenderType.translucent()) { // render tesr and particle before translucent
                        setDefaultRenderLayerState(null);
                        renderTESR(renderedBlocks, poseStack, buffers, hook, particleTicks);

                        if (hook != null || !endBatchLast) {
                            buffers.endBatch();
                        }

                        if (particleManager != null) {
                            poseStack.pushPose();
                            poseStack.setIdentity();
                            poseStack.translate(cameraEntity.getX(), cameraEntity.getY(), cameraEntity.getZ());
                            particleManager.render(poseStack, camera, particleTicks, type -> !isTranslucentParticleRenderType(type));
                            poseStack.popPose();
                        }
                    }

                    setDefaultRenderLayerState(layer);
                    if (hook != null) {
                        hook.apply(layer);
                    }

                    var buffer = buffers.getBuffer(layer);

                    renderBlocks(poseStack, bsr, layer, new VertexConsumerWrapper(buffer), renderedBlocks, randomSource, hook, particleTicks);

                    if (!endBatchLast) {
                        buffers.endBatch();
                    }
                    layer.clearRenderState();
                }
            });
        }

        if (world instanceof TrackedDummyWorld level) {
            PoseStack poseStack = new PoseStack();
            renderEntities(level, poseStack, buffers, sceneEntityRenderHook, particleTicks);
        }

        if (beforeBatchEnd != null) {
            beforeBatchEnd.accept(buffers, particleTicks);
        }

        buffers.endBatch();

        if (particleManager != null) { // render translucent particles
            @Nonnull PoseStack poseStack = new PoseStack();
            poseStack.setIdentity();
            poseStack.translate(cameraEntity.getX(), cameraEntity.getY(), cameraEntity.getZ());
            particleManager.render(poseStack, camera, particleTicks, WorldSceneRenderer::isTranslucentParticleRenderType);
        }

        if (afterWorldRender != null) {
            afterWorldRender.accept(this);
        }
    }

    public boolean isCompiling() {
        return cacheState.get() == CacheState.COMPILING;
    }

    public double getCompileProgress() {
        if (maxProgress > 1000) {
            return progress * 1. / maxProgress;
        }
        return 0;
    }

    private void renderCacheBuffer(Minecraft mc, MultiBufferSource.BufferSource buffers, float particleTicks) {
        List<RenderType> layers = RenderType.chunkBufferLayers();
        CacheState state = cacheState.get();
        if (state == CacheState.NEED || state == CacheState.UNCREATED) {
            makeSureCacheBufferCreated();
            progress = 0;
            maxProgress = renderedBlocksMap.values().stream().map(e -> e.snapshot().size()).reduce(0, Integer::sum) * (layers.size() + 1);
            if (syncCompile) {
                startSyncCompile(layers);
                // fall through and render whatever (if any) is currently uploaded
            } else {
                startAsyncCompile(mc, layers);
                return;
            }
        }
        if (syncCompile && cacheState.get() == CacheState.COMPILING && syncCompileState != null) {
            tickSyncCompile(mc);
        }
        renderUploadedBuffers(mc, buffers, particleTicks, layers);
    }

    private void startAsyncCompile(Minecraft mc, List<RenderType> layers) {
        thread = new Thread(() -> {
            cacheState.set(CacheState.COMPILING);
            BlockRenderDispatcher blockrendererdispatcher = mc.getBlockRenderer();
            var randomSource = RandomSource.createNewThreadLocalInstance();
            try { // render the blocks in each layer
                ModelBlockRenderer.enableCaching();
                PoseStack matrixstack = new PoseStack();
                for (int i = 0; i < layers.size(); i++) {
                    if (Thread.interrupted())
                        return;
                    RenderType layer = layers.get(i);
                    BufferBuilder buffer = new BufferBuilder(layer.bufferSize());
                    buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.BLOCK);
                    renderedBlocksMap.forEach((key, entry) -> {
                        renderBlocks(matrixstack, blockrendererdispatcher, layer, new VertexConsumerWrapper(buffer), entry.snapshot(), randomSource, entry.hook(), 0);
                    });
                    BufferBuilder.RenderedBuffer data = buffer.endOrDiscardIfEmpty();
                    if (data == null) {
                        vertexBuffersUsingMark[i] = false;
                        continue;
                    }

                    vertexBuffersUsingMark[i] = true;
                    var vertexBuffer = vertexBuffers[i];
                    Runnable toUpload = () -> {
                        if (!vertexBuffer.isInvalid()) {
                            vertexBuffer.bind();
                            vertexBuffer.upload(data);
                            VertexBuffer.unbind();
                        }
                    };
                    CompletableFuture.runAsync(toUpload, runnable -> {
                        RenderSystem.recordRenderCall(runnable::run);
                    });
                }
                ModelBlockRenderer.clearCache();
            } finally {
            }
            Set<BlockPos> poses = new HashSet<>();
            renderedBlocksMap.forEach((key, entry) -> {
                for (BlockPos pos : entry.snapshot()) {
                    progress++;
                    if (Thread.interrupted())
                        return;
                    BlockEntity tile = world.getBlockEntity(pos);
                    if (tile != null) {
                        if (mc.getBlockEntityRenderDispatcher().getRenderer(tile) != null) {
                            poses.add(pos);
                        }
                    }
                }
            });
            if (Thread.interrupted())
                return;
            tileEntities = poses;
            if (thread != null) {
                cacheState.set(CacheState.COMPILED);
                thread = null;
            }
            maxProgress = -1;
        });
        thread.start();
    }

    private void startSyncCompile(List<RenderType> layers) {
        // Snapshot entries up front so later add/remove calls don't disturb the in-flight cursor
        // (and don't need to walk renderedBlocksMap concurrently).
        var entriesSnapshot = List.copyOf(renderedBlocksMap.values());
        syncCompileState = new SyncCompileState(layers, entriesSnapshot);
        cacheState.set(CacheState.COMPILING);
    }

    /**
     * Advances the sync-mode compile by up to {@link #syncCompileMaxBlocksPerFrame} blocks or
     * {@link #syncCompileTimeBudgetNanos} of wall time, whichever comes first. Guarantees forward
     * progress of at least one step per call.
     */
    private void tickSyncCompile(Minecraft mc) {
        var s = syncCompileState;
        if (s == null) return;
        long deadline = System.nanoTime() + syncCompileTimeBudgetNanos;
        BlockRenderDispatcher bsr = mc.getBlockRenderer();
        ModelBlockRenderer.enableCaching();
        try {
            int processed = 0;
            while (processed < syncCompileMaxBlocksPerFrame) {
                boolean advanced;
                if (!s.tilePhase) {
                    advanced = stepSyncBlockPhase(s, bsr);
                    if (!advanced) {
                        // block phase fully done; switch to tile-entity scan
                        s.tilePhase = true;
                        continue;
                    }
                } else {
                    advanced = stepSyncTilePhase(s, mc);
                    if (!advanced) {
                        // tile phase fully done — compile complete
                        tileEntities = s.collectedTiles;
                        syncCompileState = null;
                        cacheState.set(CacheState.COMPILED);
                        maxProgress = -1;
                        return;
                    }
                }
                processed++;
                if (System.nanoTime() >= deadline) break;
            }
        } finally {
            ModelBlockRenderer.clearCache();
        }
    }

    /**
     * Processes one block in the current layer/entry. Returns true if a step happened (caller
     * should keep going within budget); false when there is nothing left in the block phase.
     */
    private boolean stepSyncBlockPhase(SyncCompileState s, BlockRenderDispatcher bsr) {
        while (s.layerIndex < s.layers.size()) {
            RenderType layer = s.layers.get(s.layerIndex);
            if (s.currentBuffer == null) {
                s.currentBuffer = new BufferBuilder(layer.bufferSize());
                s.currentBuffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.BLOCK);
                s.entryIndex = 0;
                s.blockIter = null;
            }
            while (s.entryIndex < s.entries.size()) {
                RenderedBlocksEntry entry = s.entries.get(s.entryIndex);
                if (s.blockIter == null) {
                    s.blockIter = entry.snapshot().iterator();
                }
                if (s.blockIter.hasNext()) {
                    BlockPos pos = s.blockIter.next();
                    renderSingleBlock(s.matrixStack, bsr, layer, new VertexConsumerWrapper(s.currentBuffer), pos, entry.hook(), s.randomSource, 0);
                    if (maxProgress > 0) progress++;
                    return true;
                }
                s.blockIter = null;
                s.entryIndex++;
            }
            // current layer is fully traversed — build + upload (we're on the render thread)
            finalizeSyncLayer(s);
            s.currentBuffer = null;
            s.layerIndex++;
        }
        return false;
    }

    private boolean stepSyncTilePhase(SyncCompileState s, Minecraft mc) {
        while (s.tileEntryIndex < s.entries.size()) {
            RenderedBlocksEntry entry = s.entries.get(s.tileEntryIndex);
            if (s.tileBlockIter == null) {
                s.tileBlockIter = entry.snapshot().iterator();
            }
            if (s.tileBlockIter.hasNext()) {
                BlockPos pos = s.tileBlockIter.next();
                if (maxProgress > 0) progress++;
                BlockEntity tile = world.getBlockEntity(pos);
                if (tile != null && mc.getBlockEntityRenderDispatcher().getRenderer(tile) != null) {
                    s.collectedTiles.add(pos);
                }
                return true;
            }
            s.tileBlockIter = null;
            s.tileEntryIndex++;
        }
        return false;
    }

    private void finalizeSyncLayer(SyncCompileState s) {
        if (s.currentBuffer == null) return;
        int idx = s.layerIndex;
        BufferBuilder.RenderedBuffer data = s.currentBuffer.endOrDiscardIfEmpty();
        if (data == null) {
            vertexBuffersUsingMark[idx] = false;
            return;
        }
        vertexBuffersUsingMark[idx] = true;
        VertexBuffer vb = vertexBuffers[idx];
        if (vb != null && !vb.isInvalid()) {
            vb.bind();
            vb.upload(data);
            VertexBuffer.unbind();
        } else {
            data.release();
        }
    }

    private void renderUploadedBuffers(Minecraft mc, MultiBufferSource.BufferSource buffers, float particleTicks, List<RenderType> layers) {
        var poseStack = new PoseStack();
        for (int i = 0; i < layers.size(); i++) {
            var layer = layers.get(i);
            if (layer == RenderType.translucent() && tileEntities != null) { // render tesr before translucent
                if (world instanceof TrackedDummyWorld level) {
                    renderEntities(level, poseStack, buffers, sceneEntityRenderHook, particleTicks);
                }
                renderTESR(tileEntities, poseStack, mc.renderBuffers().bufferSource(), null, particleTicks);
                if (!endBatchLast) {
                    buffers.endBatch();
                }

                if (particleManager != null) {
                    poseStack.pushPose();
                    poseStack.setIdentity();
                    poseStack.translate(cameraEntity.getX(), cameraEntity.getY(), cameraEntity.getZ());
                    particleManager.render(poseStack, camera, particleTicks, type -> !isTranslucentParticleRenderType(type));
                    poseStack.popPose();
                }
            }

            var vertexbuffer = vertexBuffers[i];
            if (vertexbuffer == null || !vertexBuffersUsingMark[i] || vertexbuffer.isInvalid() || vertexbuffer.getFormat() == null)
                continue;

            layer.setupRenderState();

            poseStack.pushPose();

            ShaderInstance shaderInstance = RenderSystem.getShader();

            for (int j = 0; j < 12; ++j) {
                int k = RenderSystem.getShaderTexture(j);
                shaderInstance.setSampler("Sampler" + j, k);
            }

            // setup shader uniform
            if (shaderInstance.MODEL_VIEW_MATRIX != null) {
                shaderInstance.MODEL_VIEW_MATRIX.set(RenderSystem.getModelViewMatrix());
            }

            if (shaderInstance.PROJECTION_MATRIX != null) {
                shaderInstance.PROJECTION_MATRIX.set(RenderSystem.getProjectionMatrix());
            }

            if (shaderInstance.COLOR_MODULATOR != null) {
                shaderInstance.COLOR_MODULATOR.set(RenderSystem.getShaderColor());
            }

            if (shaderInstance.FOG_START != null) {
                shaderInstance.FOG_START.set(RenderSystem.getShaderFogStart());
            }

            if (shaderInstance.FOG_END != null) {
                shaderInstance.FOG_END.set(RenderSystem.getShaderFogEnd());
            }

            if (shaderInstance.FOG_COLOR != null) {
                shaderInstance.FOG_COLOR.set(RenderSystem.getShaderFogColor());
            }

            if (shaderInstance.FOG_SHAPE != null) {
                shaderInstance.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
            }

            if (shaderInstance.TEXTURE_MATRIX != null) {
                shaderInstance.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
            }

            if (shaderInstance.GAME_TIME != null) {
                shaderInstance.GAME_TIME.set(RenderSystem.getShaderGameTime());
            }

            RenderSystem.setupShaderLights(shaderInstance);
            shaderInstance.apply();

            setDefaultRenderLayerState(layer);

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

            vertexbuffer.bind();
            vertexbuffer.draw();

            poseStack.popPose();

            shaderInstance.clear();
            VertexBuffer.unbind();
            layer.clearRenderState();
        }
    }

    private void renderBlocks(PoseStack poseStack, BlockRenderDispatcher brd, RenderType layer, VertexConsumerWrapper wrapperBuffer, Collection<BlockPos> renderedBlocks, RandomSource randomSource, @Nullable ISceneBlockRenderHook hook, float partialTicks) {
        for (BlockPos pos : renderedBlocks) {
            renderSingleBlock(poseStack, brd, layer, wrapperBuffer, pos, hook, randomSource, partialTicks);
            if (maxProgress > 0) {
                progress++;
            }
        }
    }

    private void renderSingleBlock(PoseStack poseStack, BlockRenderDispatcher brd, RenderType layer, VertexConsumerWrapper wrapperBuffer, BlockPos pos, @Nullable ISceneBlockRenderHook hook, RandomSource randomSource, float partialTicks) {
        if (blocked != null && blocked.contains(pos)) {
            return;
        }
        var state = world.getBlockState(pos);
        var fluidState = state.getFluidState();
        var block = state.getBlock();

        if (hook != null) {
            hook.applyVertexConsumerWrapper(world, pos, state, wrapperBuffer, layer, partialTicks);
        }

        if (block != Blocks.AIR && state.getRenderShape() != INVISIBLE) {
            var model = brd.getBlockModel(state);
            var modelData = world instanceof ClientLevel clientLevel ? clientLevel.getModelDataManager().getAt(pos) : ModelData.EMPTY;
            modelData = model.getModelData(world, pos, state, modelData);
            randomSource.setSeed(state.getSeed(pos));
            if (model.getRenderTypes(state, randomSource, modelData).contains(layer)) {
                poseStack.pushPose();
                poseStack.translate(pos.getX(), pos.getY(), pos.getZ());
                brd.renderBatched(state, pos, world, poseStack, wrapperBuffer, false, randomSource, modelData, layer);
                poseStack.popPose();
            }
        }
        if (!fluidState.isEmpty() && ItemBlockRenderTypes.getRenderLayer(fluidState) == layer) {
            wrapperBuffer.addOffset((pos.getX() - (pos.getX() & 15)), (pos.getY() - (pos.getY() & 15)), (pos.getZ() - (pos.getZ() & 15)));
            brd.renderLiquid(pos, world, wrapperBuffer, state, fluidState);
        }
        wrapperBuffer.clearOffset();
        wrapperBuffer.clearColor();
    }

    private void renderTESR(Collection<BlockPos> poses, PoseStack poseStack, MultiBufferSource.BufferSource buffers, @Nullable ISceneBlockRenderHook hook, float partialTicks) {
        for (var pos : poses) {
            var tile = world.getBlockEntity(pos);
            if (tile != null) {
                poseStack.pushPose();
                poseStack.translate(pos.getX(), pos.getY(), pos.getZ());
                var beRenderer = Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(tile);
                if (beRenderer != null) {
                    if (tile.hasLevel() && tile.getType().isValid(tile.getBlockState())) {
                        Level world = tile.getLevel();

                        if (hook != null) {
                            hook.applyBESR(world, pos, tile, poseStack, partialTicks);
                        }

                        beRenderer.render(tile, partialTicks, poseStack, buffers, 0xF000F0, OverlayTexture.NO_OVERLAY);
                    }
                }
                poseStack.popPose();
            }
        }
    }

    private static boolean isTranslucentParticleRenderType(ParticleRenderType type) {
        return type == ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    private void renderEntities(TrackedDummyWorld level, PoseStack poseStack, MultiBufferSource buffer, @Nullable ISceneEntityRenderHook hook, float partialTicks) {
        for (var entity : level.getAllRenderedEntities()) {
            poseStack.pushPose();
            if (entity.tickCount == 0) {
                entity.xOld = entity.getX();
                entity.yOld = entity.getY();
                entity.zOld = entity.getZ();
            }
            double d0 = Mth.lerp((double) partialTicks, entity.xOld, entity.getX());
            double d1 = Mth.lerp((double) partialTicks, entity.yOld, entity.getY());
            double d2 = Mth.lerp((double) partialTicks, entity.zOld, entity.getZ());
            float f = Mth.lerp(partialTicks, entity.yRotO, entity.getYRot());
            var renderManager = Minecraft.getInstance().getEntityRenderDispatcher();
            int light = renderManager.getRenderer(entity).getPackedLightCoords(entity, partialTicks);
            if (hook != null) {
                hook.applyEntity(world, entity, poseStack, partialTicks);
            }
            renderManager.render(entity, d0, d1, d2, f, partialTicks, poseStack, buffer, light);
            poseStack.popPose();
        }
    }


    public static void setDefaultRenderLayerState(RenderType layer) {
        RenderSystem.setShaderColor(1, 1, 1, 1);
        if (layer == RenderType.translucent()) { // TRANSLUCENT
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            RenderSystem.depthMask(false);
        } else { // SOLID
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
        }
    }

    public BlockHitResult rayTrace(Vector3f hitPos) {
        var startPos = new Vec3(this.eyePos.x(), this.eyePos.y(), this.eyePos.z());
        if (ortho) {
            startPos = startPos.add(new Vec3(startPos.x - lookAt.x(), startPos.y - lookAt.y(), startPos.z - lookAt.z()).multiply(500, 500, 500));
        }
        hitPos = hitPos.mul(2, new Vector3f()); // Double view range to ensure pos can be seen.
        var endPos = new Vec3((hitPos.x() - startPos.x), (hitPos.y() - startPos.y), (hitPos.z() - startPos.z));
        try {
            return this.world.clip(new ClipContext(startPos, endPos, clipBlock, clipFluid, cameraEntity));
        } catch (Exception e) {
            return null;
        }
    }

    public Vector3f project(Vector3f pos) {
        //read current rendering parameters
        RenderSystem.getModelViewMatrix().get(MODELVIEW_MATRIX_BUFFER);
        RenderSystem.getProjectionMatrix().get(PROJECTION_MATRIX_BUFFER);
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, VIEWPORT_BUFFER);

        //rewind buffers after write by OpenGL glGet calls
        MODELVIEW_MATRIX_BUFFER.rewind();
        PROJECTION_MATRIX_BUFFER.rewind();
        VIEWPORT_BUFFER.rewind();

        //call gluProject with retrieved parameters
        Project.gluProject(pos.x(), pos.y(), pos.z(), MODELVIEW_MATRIX_BUFFER, PROJECTION_MATRIX_BUFFER, VIEWPORT_BUFFER, OBJECT_POS_BUFFER);

        //rewind buffers after read by gluProject
        VIEWPORT_BUFFER.rewind();
        PROJECTION_MATRIX_BUFFER.rewind();
        MODELVIEW_MATRIX_BUFFER.rewind();

        //rewind buffer after write by gluProject
        OBJECT_POS_BUFFER.rewind();

        //obtain position in Screen
        float winX = OBJECT_POS_BUFFER.get();
        float winY = OBJECT_POS_BUFFER.get();
        float winZ = OBJECT_POS_BUFFER.get();

        //rewind buffer after read
        OBJECT_POS_BUFFER.rewind();

        return new Vector3f(winX, winY, winZ);
    }

    public Vector3f unProject(int mouseX, int mouseY) {
        return unProject(mouseX, mouseY, true);
    }

    public Vector3f unProject(int mouseX, int mouseY, boolean checkDepth) {
        var pixelDepth = 0.999f;
        if (checkDepth) {
            //read depth of pixel under mouse
            GL11.glReadPixels(mouseX, mouseY, 1, 1, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, PIXEL_DEPTH_BUFFER);

            //rewind buffer after write by glReadPixels
            PIXEL_DEPTH_BUFFER.rewind();

            //retrieve depth from buffer (0.0-1.0f)
            pixelDepth = PIXEL_DEPTH_BUFFER.get();
        }

        //rewind buffer after read
        PIXEL_DEPTH_BUFFER.rewind();

        //read current rendering parameters
        RenderSystem.getModelViewMatrix().get(MODELVIEW_MATRIX_BUFFER);
        RenderSystem.getProjectionMatrix().get(PROJECTION_MATRIX_BUFFER);
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, VIEWPORT_BUFFER);

        //rewind buffers after write by OpenGL glGet calls
        MODELVIEW_MATRIX_BUFFER.rewind();
        PROJECTION_MATRIX_BUFFER.rewind();
        VIEWPORT_BUFFER.rewind();

        //call gluUnProject with retrieved parameters
        Project.gluUnProject(mouseX, mouseY, pixelDepth, MODELVIEW_MATRIX_BUFFER, PROJECTION_MATRIX_BUFFER, VIEWPORT_BUFFER, OBJECT_POS_BUFFER);

        //rewind buffers after read by gluUnProject
        VIEWPORT_BUFFER.rewind();
        PROJECTION_MATRIX_BUFFER.rewind();
        MODELVIEW_MATRIX_BUFFER.rewind();

        //rewind buffer after write by gluUnProject
        OBJECT_POS_BUFFER.rewind();

        //obtain absolute position in world
        float posX = OBJECT_POS_BUFFER.get();
        float posY = OBJECT_POS_BUFFER.get();
        float posZ = OBJECT_POS_BUFFER.get();

        //rewind buffer after read
        OBJECT_POS_BUFFER.rewind();

        return new Vector3f(posX, posY, posZ);
    }

    /***
     * For better performance, You'd better handle the event {@link #setOnLookingAt(Consumer)} or {@link #getLastTraceResult()}
     * @param mouseX xPos in Texture
     * @param mouseY yPos in Texture
     * @return RayTraceResult Hit
     */
    protected BlockHitResult screenPos2BlockPosFace(int mouseX, int mouseY, int x, int y, int width, int height) {
        // render a frame
        RenderSystem.enableDepthTest();
        setupCamera(getPositionedRect(x, y, width, height));

        drawWorld();

        Vector3f hitPos = this.lastHit == null ? unProject(mouseX, mouseY) : this.lastHit;
        BlockHitResult result = rayTrace(hitPos);

        resetCamera();

        return result;
    }

    /***
     * For better performance, You'd better do project in {@link #setAfterWorldRender(Consumer)}
     * @param pos BlockPos
     * @param depth should pass Depth Test
     * @return x, y, z
     */
    protected Vector3f blockPos2ScreenPos(BlockPos pos, boolean depth, int x, int y, int width, int height) {
        // render a frame
        RenderSystem.enableDepthTest();
        setupCamera(getPositionedRect(x, y, width, height));

        drawWorld();
        Vector3f winPos = project(new Vector3f(pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f));

        resetCamera();

        return winPos;
    }

    public static class VertexConsumerWrapper implements VertexConsumer {

        final VertexConsumer builder;
        @Setter
        float offsetX, offsetY, offsetZ;
        float r = 1, g = 1, b = 1, a = 1;

        public VertexConsumerWrapper(VertexConsumer builder) {
            this.builder = builder;
        }

        public void addOffset(float offsetX, float offsetY, float offsetZ) {
            this.offsetX += offsetX;
            this.offsetY += offsetY;
            this.offsetZ += offsetZ;
        }

        public void setColorMultiplier(float r, float g, float b, float a) {
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }

        public void clearOffset() {
            this.offsetX = 0;
            this.offsetY = 0;
            this.offsetZ = 0;
        }

        public void clearColor() {
            this.r = 1;
            this.g = 1;
            this.b = 1;
            this.a = 1;
        }

        @Override
        public VertexConsumer vertex(double x, double y, double z) {
            return builder.vertex(x + offsetX, y + offsetY, z + offsetZ);
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            return builder.color((int) (red * r), (int) (green * g), (int) (blue * b), (int) (alpha * a));
        }

        @Override
        public VertexConsumer uv(float u, float v) {
            return builder.uv(u, v);
        }

        @Override
        public VertexConsumer overlayCoords(int u, int v) {
            return builder.overlayCoords(u, v);
        }

        @Override
        public VertexConsumer uv2(int u, int v) {
            return builder.uv2(u, v);
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            return builder.normal(x, y, z);
        }

        @Override
        public void endVertex() {
            builder.endVertex();
        }

        @Override
        public void defaultColor(int red, int green, int blue, int alpha) {
            builder.defaultColor((int) (red * r), (int) (green * g), (int) (blue * b), (int) (alpha * a));
        }

        @Override
        public void unsetDefaultColor() {
            builder.unsetDefaultColor();
        }
    }
}
