package com.lowdragmc.lowdraglib2.gui.ui.elements;

import com.lowdragmc.lowdraglib2.gui.ColorPattern;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.ui.ModularUI;
import com.lowdragmc.lowdraglib2.gui.ui.Style;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.data.Horizontal;
import com.lowdragmc.lowdraglib2.gui.ui.data.TextWrap;
import com.lowdragmc.lowdraglib2.gui.ui.data.Vertical;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvent;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.ui.layout.LayoutProperties;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.GUIContext;
import com.lowdragmc.lowdraglib2.gui.ui.style.StyleOrigin;
import com.lowdragmc.lowdraglib2.gui.ui.styletemplate.Sprites;
import com.lowdragmc.lowdraglib2.gui.util.FileNode;
import com.lowdragmc.lowdraglib2.gui.util.WindowDragHelper;
import com.lowdragmc.lowdraglib2.integration.kjs.KJSBindings;
import dev.vfyjxf.taffy.style.*;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import lombok.Setter;
import lombok.experimental.Accessors;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.appliedenergistics.yoga.style.StyleSizeLength;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

@KJSBindings
public class Dialog extends UIElement {
    /**
     * Optional features of {@link Dialog#showFileDialog}, combined with {@code |}:
     * <pre>{@code showFileDialog(title, dir, true, valid, FileFeature.NEW_FOLDER | FileFeature.RENAME, result)}</pre>
     * The overloads without a feature mask enable {@link #ALL} of them.
     */
    public interface FileFeature {
        /** A plain file picker: no folder button, no editing. */
        int NONE = 0;
        /** The button that selects a directory with the system folder picker. */
        int OPEN_FOLDER = 1;
        /** Right click on the tree to create a folder. */
        int NEW_FOLDER = 1 << 1;
        /** Right click on the tree to rename a file or folder. */
        int RENAME = 1 << 2;
        /** Right click on the tree to delete a file or folder, after a confirmation. */
        int DELETE = 1 << 3;
        /** Every feature above. */
        int ALL = OPEN_FOLDER | NEW_FOLDER | RENAME | DELETE;

        static boolean has(int features, int feature) {
            return (features & feature) != 0;
        }
    }

    /**
     * How long past a {@link #showNotification(String, float)} progress bar's own duration the fallback
     * deadline waits before closing the dialog itself, so a bar advancing normally always gets there
     * first.
     */
    private static final long NOTIFICATION_GRACE_MS = 500;
    /** The smallest a {@link #windowMode window mode} dialog can be resized to. */
    static final float MIN_WINDOW_SIZE = 50;

    public final UIElement overlay;
    public final UIElement titleBar;
    public final UIElement contentContainer;
    public final UIElement buttonContainer;
    /**
     * Elements displayed outside the dialog's element tree, but logically belonging to it.
     * @see #addExternalElement(UIElement)
     */
    private final List<UIElement> externalElements = new ArrayList<>();
    private boolean autoClose = true;
    private boolean clickOutsideClose = false;
    @Nullable
    @Setter @Accessors(chain = true)
    private Runnable onClose;
    private boolean windowMode = false;
    private boolean isResizing;
    private float windowWidth, windowHeight;
    @Nullable
    private String sizeKey;
    private boolean resized;

    public Dialog() {
        this.titleBar = new UIElement().addClass("__dialog_title__");
        this.contentContainer = new UIElement().addClass("__dialog_content-container__");
        this.buttonContainer = new UIElement().addClass("__dialog_button-container__");
        this.setFocusable(true);
        this.getLayout().positionType(TaffyPosition.ABSOLUTE);
        this.getLayout().widthPercent(100);
        this.getLayout().heightPercent(100);
        this.getLayout().justifyContent(AlignContent.CENTER);
        this.getLayout().alignItems(AlignItems.CENTER);
        this.getStyle().zIndex(1);

        this.overlay = new UIElement().layout(layout -> {
            layout.alignItems(AlignItems.CENTER);
            layout.justifyContent(AlignContent.CENTER);
            layout.width(150);
        }).addClass("__dialog_overlay__");

        this.titleBar.layout(layout -> {
            layout.flexDirection(FlexDirection.ROW);
            layout.gapAll(2);
            layout.setPipelineState(StyleOrigin.DEFAULT);
            layout.widthPercent(100);
            layout.alignItems(AlignItems.CENTER);
            layout.paddingAll(5);
            layout.setPipelineState(StyleOrigin.INLINE);
        }).style(style -> style.backgroundTexture(Sprites.BORDER1_RT1));

        this.contentContainer.layout(layout -> {
            layout.widthPercent(100);
            layout.alignItems(AlignItems.CENTER);
            layout.justifyContent(AlignContent.CENTER);
            layout.paddingAll(4);
            layout.gapAll(2);
        }).style(style -> style.backgroundTexture(Sprites.RECT_SOLID));

        this.buttonContainer.layout(layout -> {
            layout.widthPercent(100);
            layout.alignItems(AlignItems.CENTER);
            layout.justifyContent(AlignContent.CENTER);
            layout.flexDirection(FlexDirection.ROW);
            layout.paddingAll(4);
            layout.gapAll(2);
        }).style(style -> style.backgroundTexture(Sprites.RECT_SOLID));

        overlay.addChildren(titleBar, contentContainer, buttonContainer);

        addChild(overlay);

        stopInteractionEventsPropagation();
        addEventListener(UIEvents.BLUR, this::onBlur, true);
        addEventListener(UIEvents.KEY_DOWN, this::keyDown);
        addEventListener(UIEvents.MOUSE_DOWN, this::mouseDown);

        internalSetup();
    }

    @Override
    public String name() {
        return "dialog";
    }

    public Dialog allowInteraction() {
        getLayout().widthAuto();
        getLayout().heightAuto();
        getLayout().alignSelf(AlignItems.CENTER);

        this.addEventListener(UIEvents.MOUSE_DOWN, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.MOUSE_UP, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.CLICK, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.DOUBLE_CLICK, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.MOUSE_MOVE, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.MOUSE_WHEEL, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.DRAG_UPDATE, UIEvent::stopLaterPropagation);
        this.addEventListener(UIEvents.DRAG_PERFORM, UIEvent::stopLaterPropagation);
        return this;
    }

    protected void keyDown(UIEvent event) {
        if (autoClose && event.keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            event.stopPropagation();
        }
    }

    protected void mouseDown(UIEvent event) {
        if (clickOutsideClose && autoClose && !overlay.isSelfOrChildHover()) {
            if (isInsideDialog() || isExternalElementInteracted(null)) {
                return;
            }
            close();
            event.stopPropagation();
        }
    }

    protected void onBlur(UIEvent event) {
        if (event.relatedTarget != null && this.isAncestorOf(event.relatedTarget)) { // focus on children
            return;
        }
        if (isInsideDialog()) { // focus on sibling popup/menu
            return;
        }
        if (isExternalElementInteracted(event.relatedTarget)) { // interacting with an external popup of this dialog
            return;
        }

        if (event.target == this) { // lose focus
            if (event.relatedTarget != null && !this.isAncestorOf(event.relatedTarget)) {
                if (autoClose) {
                    close();
                }
                return;
            }
            if (isSelfOrChildHover()) {
                focus();
            } else {
                if (autoClose) {
                    close();
                }
            }
        } else { // child lose focus
            if (event.relatedTarget == null && isSelfOrChildHover()) {
                focus();
            } else {
                if (autoClose) {
                    close();
                }
            }
        }
    }

    /**
     * Registers an element that is displayed outside the dialog's element tree, e.g. the dropdown of a
     * {@link SearchComponent}, which is anchored to the root element. Such an element is considered as a part of the
     * dialog, so that interacting with it won't dismiss the dialog even if the auto close is enabled.
     */
    public Dialog addExternalElement(UIElement element) {
        externalElements.add(element);
        return this;
    }

    /**
     * Un-registers an element added by {@link #addExternalElement(UIElement)}, e.g. when the popup it
     * stands for is closed.
     */
    public Dialog removeExternalElement(UIElement element) {
        externalElements.remove(element);
        return this;
    }

    private boolean isExternalElementInteracted(@Nullable UIElement focused) {
        for (var element : externalElements) {
            if (element.isSelfOrChildHover() || element.isAncestorOf(focused)) {
                return true;
            }
        }
        return false;
    }

    private boolean isInsideDialog() {
        var mui = getModularUI();
        if (mui == null) return false;
        var localMouse = overlay.worldToLocal(new Vector2f(mui.getLastMouseX(), mui.getLastMouseY()));
        return overlay.isIntersectWithPoint(localMouse.x, localMouse.y);
    }

    /**
     * Closes the dialog and removes it from its parent if it has one.
     */
    public void close(){
        if (this.getParent() != null) {
            this.getParent().removeChild(this);
            if (onClose != null) {
                onClose.run();
            }
        }
    }

    /**
     * Sets whether the dialog should close automatically when the escape key is pressed.
     *
     * @param autoClose true to enable auto-close, false to disable
     * @return this dialog instance for method chaining
     */
    public Dialog setAutoClose(boolean autoClose) {
        this.autoClose = autoClose;
        return this;
    }

    /**
     * Sets whether the dialog should close automatically when the mouse is clicked outside of the dialog.
     *
     * @param clickOutsideClose true to enable auto-close, false to disable
     * @return this dialog instance for method chaining
     */
    public Dialog setClickOutsideClose(boolean clickOutsideClose) {
        this.clickOutsideClose = clickOutsideClose;
        return this;
    }

    /**
     * Shows the dialog as a child of the specified UIElement parent.
     * This will add the dialog to the parent's children and focus it.
     * NOTE: ypu should always call this method to show the dialog after creating it,
     *
     * @param parent the UIElement that will be the parent of this dialog
     */
    public Dialog show(UIElement parent) {
        buttonContainer.setDisplay(!buttonContainer.getChildren().isEmpty());
        contentContainer.setDisplay(!contentContainer.getChildren().isEmpty());
        titleBar.setDisplay(!titleBar.getChildren().isEmpty());

        parent.addChild(this);
        focus();
        return this;
    }

    /**
     * Displays the dialog on the top of the specified {@link ModularUI} instance.
     *
     * If the provided {@code modularUI} is null, this method will return the current
     * dialog instance without performing any action.
     *
     * @param modularUI the {@code ModularUI} instance used to display the dialog;
     *                  it may be null, in which case no action is performed
     * @return the current {@code Dialog} instance for method chaining
     */
    public Dialog show(@Nullable ModularUI modularUI) {
        if (modularUI == null) return this;
        return show(modularUI.ui.rootElement);
    }

    /**
     * Sets the width of the dialog. by default, it will be 150px.
     */
    @Deprecated
    public Dialog width(StyleSizeLength width) {
        overlay.layout(layout -> layout.width(width));
        return this;
    }

    public Dialog width(TaffyDimension width) {
        overlay.layout(layout -> layout.setWidth(width));
        return this;
    }

    public Dialog windowMode(float worldX, float worldY) {
        return windowMode(worldX, worldY, 200, 150);
    }

    public Dialog windowMode(float worldX, float worldY, float width, float height) {
        windowMode = true;
        windowWidth = width;
        windowHeight = height;
        setClickOutsideClose(true);
        this.getLayout().justifyContent(AlignContent.FLEX_START);
        this.getLayout().alignItems(AlignItems.STRETCH);
        overlay.getLayout().width(width).height(height);
        contentContainer.getLayout().flex(1);
        // move and resize behaviour
        WindowDragHelper.setDragMove(titleBar, overlay, null, null);
        WindowDragHelper.setBorderResize(overlay, overlay, 2,
                new Vector2f(MIN_WINDOW_SIZE),
                new Vector2f(Float.MAX_VALUE),
                e -> windowMode, (e, handle) -> {
                    isResizing = true;
                    return true;
                }, e -> {
                    isResizing = false;
                    resized = true;
                });
        addEventListener(UIEvents.LAYOUT_CHANGED, e -> {
            var parent = getParent();
            if (parent != null) {
                var local = parent.worldToLocalLayoutOffset(new Vector2f(worldX, worldY));
                overlay.getLayout().left(local.x).top(local.y);
                var mui = getModularUI();
                if (mui != null && (windowWidth > mui.getScreenWidth() || windowHeight > mui.getScreenHeight())) {
                    // a remembered size may be more than the screen it opens on
                    overlay.getLayout().width(Math.min(windowWidth, mui.getScreenWidth()))
                            .height(Math.min(windowHeight, mui.getScreenHeight()));
                }
                e.currentElement.addEventListener(UIEvents.LAYOUT_CHANGED, e2 -> {
                    overlay.adaptPositionToScreen();
                });
            }
            e.currentElement.removeEventListener(UIEvents.LAYOUT_CHANGED, e.currentListener);
        });
        return this;
    }

    /**
     * Opens this {@link #windowMode window mode} dialog at the size the user last resized one with the same key to,
     * and remembers the size it gets resized to in turn, see {@link DialogSizeStore}. Call it after windowMode.
     */
    public Dialog rememberSize(String key) {
        sizeKey = key;
        var size = DialogSizeStore.get(key);
        if (size != null) {
            windowWidth = size.x;
            windowHeight = size.y;
            overlay.getLayout().width(size.x).height(size.y);
        }
        return this;
    }

    @Override
    protected void onRemoved() {
        super.onRemoved();
        if (sizeKey != null && resized) {
            DialogSizeStore.put(sizeKey, overlay.getSizeWidth(), overlay.getSizeHeight());
        }
    }

    /**
     * Draw a dark background behind the dialog.
     */
    public Dialog darkenBackground() {
        this.style(style -> style.backgroundTexture(ColorPattern.T_BLACK.rectTexture()));
        return this;
    }

    public Dialog top() {
        this.getLayout().justifyContent(AlignContent.FLEX_START);
        this.overlay.layout(layout -> {
            layout.top(10);
        });
        return this;
    }

    public Dialog bottom() {
        this.getLayout().justifyContent(AlignContent.FLEX_END);
        this.overlay.layout(layout -> {
            layout.bottom(10);
        });
        return this;
    }

    /**
     * Sets the title of the dialog.
     */
    public Dialog setTitle(String title) {
        titleBar.clearAllChildren();
        titleBar.addChild(new Label()
                .textStyle(style -> style
                        .textAlignVertical(Vertical.CENTER)
                        .textAlignHorizontal(Horizontal.CENTER)
                        .adaptiveWidth(true))
                .setText(title));
        return this;
    }

    /**
     * Adds a content element to the dialog.
     * The content will be added to the middle of the dialog.
     */
    public Dialog addContent(UIElement content) {
        contentContainer.addChild(content);
        return this;
    }

    /**
     * Adds a button to the dialog.
     * The button will be added to the button container at the bottom of the dialog.
     */
    public Dialog addButton(UIElement button) {
        buttonContainer.addChild(button);
        return this;
    }

    /**
     * Creates a dialog for editing a string value.
     * This dialog will have a text field for input and two buttons: confirm and cancel.
     * The confirm button will call the provided result consumer with the input text.
     * Don't forget to call {@link Dialog#show(UIElement)} to display the dialog.
     *
     * @param title the title of the dialog
     * @param initial the initial text to display in the text field
     * @param predicate an optional predicate to validate the input text
     * @param result a consumer that will receive the input text when the confirm button is clicked
     */
    public static Dialog stringEditorDialog(String title, String initial, @Nullable Predicate<String> predicate, Consumer<String> result) {
        var textField = new TextField().setText(initial, false);
        if (predicate != null) {
            textField.setTextValidator(predicate);
        }
        var dialog = new Dialog();
        dialog.setTitle(title);
        dialog.addContent(textField.layout(layout -> layout.widthPercent(100)));
        dialog.addButton(new Button()
                .setOnClick(e -> {
                    result.accept(textField.getText());
                    dialog.close();
                })
                .setText("ldlib.gui.tips.confirm")
                .addClass("__confirm-button__"));
        dialog.addButton(new Button()
                .setOnClick(e -> dialog.close())
                .setText("ldlib.gui.tips.cancel")
                .addClass("__cancel-button__"));
        return dialog;
    }

    /**
     * Displays a notification dialog with a message and a progress bar that fills over a specified duration.
     * The dialog will automatically close when the progress bar completes.
     *
     * @param info the information text or message to display in the notification dialog
     * @param duration the duration (in seconds) for which the progress bar will fill before the dialog closes
     * @return the {@code Dialog} instance representing the notification
     */
    public static Dialog showNotification(String info, float duration) {
        var dialog = new Dialog();
        dialog.titleBar.setDisplay(false);
        dialog.addContent(new Label().textStyle(textStyle -> textStyle.textWrap(TextWrap.WRAP).adaptiveHeight(true))
                .setText(info).layout(layout -> layout.widthPercent(100)));
        dialog.top();
        dialog.allowInteraction();
        dialog.setAutoClose(false);

        // add progress bar
        dialog.overlay.addChildAt(new UIElement()
                .layout(layout -> layout.height(2).widthPercent(100))
                .addClass("__dialog_progress-bg__")
                .addChild(
                        new UIElement().layout(layout -> layout.heightPercent(100).widthPercent(0))
                                .style(style -> Style.defaultPipeline(style,
                                        s-> s.backgroundTexture(ColorPattern.WHITE.rectTexture())))
                                .addClass("__dialog_progress-bar__")
                                .animation(animation -> animation
                                        .duration(duration)
                                        .style(LayoutProperties.WIDTH, TaffyDimension.percent(1))
                                        .onFinished(target -> dialog.close())
                                        .start())
                ), 0
        );

        // A deadline as well as the bar, and belt and braces on purpose. The bar is the mechanism, and
        // the one way it was known to stall — the element tree being re-hosted by another ModularUI —
        // is handled by AnimationEngine#handOver, so nothing here is load-bearing today. What keeps it
        // is that this notification has no other way out at all: no button, no auto close, so anything
        // that stops the animation leaves it on screen permanently with no input able to dismiss it.
        // Ticks come from the Screen rather than from the UI running the animation, so they keep
        // arriving whatever became of it.
        var expiry = new long[]{0};
        dialog.addEventListener(UIEvents.TICK, e -> {
            var now = Util.getMillis();
            if (expiry[0] == 0) {
                expiry[0] = now + (long) (duration * 1000) + NOTIFICATION_GRACE_MS;
            } else if (now >= expiry[0]) {
                dialog.close();
            }
        });
        return dialog;
    }

    /**
     * Shows a notification dialog with a title and information text.
     * This dialog will have a single button to close it.
     * Don't forget to call {@link Dialog#show(UIElement)} to display the dialog.
     * @param title the title of the dialog
     * @param info the information text to display in the dialog
     * @param onClosed an optional runnable that will be called when the dialog is closed
     */
    public static Dialog showNotification(String title, String info, @Nullable Runnable onClosed) {
        var dialog = new Dialog();
        dialog.setOnClose(onClosed);
        dialog.setTitle(title);
        dialog.addContent(new Label().textStyle(textStyle -> textStyle.textWrap(TextWrap.WRAP).adaptiveHeight(true))
                .setText(info).layout(layout -> layout.widthPercent(100)));
        dialog.addButton(new Button().setOnClick(e -> dialog.close()).setText("ldlib.gui.tips.confirm").addClass("__confirm-button__"));
        return dialog;
    }

    /**
     * Shows a dialog with a title and information text, along with two buttons: confirm and cancel.
     * This dialog will call the provided BooleanConsumer with true if confirm is clicked, or false if cancel is clicked.
     * Don't forget to call {@link Dialog#show(UIElement)} to display the dialog.
     * @param title the title of the dialog
     * @param info the information text to display in the dialog
     * @param onClosed a BooleanConsumer that will be called with true if confirm is clicked, or false if cancel is clicked
     */
    public static Dialog showCheckBox(String title, String info, BooleanConsumer onClosed) {
        return showCheckBox(title, Component.translatable(info), onClosed);
    }

    /**
     * As {@link #showCheckBox(String, String, BooleanConsumer)}, for an already built message — e.g. one
     * naming the thing that is about to be removed.
     */
    public static Dialog showCheckBox(String title, Component info, BooleanConsumer onClosed) {
        var dialog = new Dialog();
        dialog.setTitle(title);
        dialog.addContent(new Label().textStyle(textStyle -> textStyle.textWrap(TextWrap.WRAP).adaptiveHeight(true))
                .setText(info).layout(layout -> layout.widthPercent(100)));
        dialog.addButton(new Button()
                .setOnClick(e -> {
                    if (onClosed != null) {
                        onClosed.accept(true);
                    }
                    dialog.close();
                })
                .setText("ldlib.gui.tips.confirm").addClass("__confirm-button__"));
        dialog.addButton(new Button()
                .setOnClick(e -> {
                    if (onClosed != null) {
                        onClosed.accept(false);
                    }
                    dialog.close();
                })
                .setText("ldlib.gui.tips.reject")
                .addClass("__reject-button__"));
        return dialog;
    }

    public static Dialog showCancelableCheck(String title, String info, BooleanConsumer onClosed, Runnable onCanceled) {
        var dialog = showCheckBox(title, info, onClosed);
        dialog.addButton(new Button()
                .setOnClick(e -> {
                    if (onCanceled != null) {
                        onCanceled.run();
                    }
                    dialog.close();
                })
                .setText("ldlib.gui.tips.cancel")
                .addClass("__cancel-button__"));
        return dialog;
    }

    /**
     * Shows a file dialog for selecting or creating files.
     * This dialog will display a tree list of files and directories starting from the specified directory.
     * You can use the text field to filter or specify the file name.
     * The dialog will have a confirm button to select the file or directory, and a cancel button to close the dialog.
     * You can also provide a predicate to validate the selected file or directory.
     * Don't forget to call {@link Dialog#show(UIElement)} to display the dialog.
     * @param title the title of the dialog
     * @param dir the directory to start from, it will be created if it does not exist
     * @param isSelector if true, the dialog will allow selecting a file or directory, otherwise it will allow creating a new file in the selected directory
     * @param valid a predicate to validate the selected file or directory, can be null to allow all files
     * @param result a consumer that will receive the selected file or directory when the confirm button is clicked
     */
    public static Dialog showFileDialog(String title, File dir, boolean isSelector, @Nullable Predicate<FileNode> valid, Consumer<File> result) {
        return showFileDialog(title, dir, isSelector, null, valid, FileFeature.ALL, result);
    }

    /**
     * Shows a file dialog offering only the given {@link FileFeature}s.
     *
     * @param features the enabled features, e.g. {@code FileFeature.OPEN_FOLDER | FileFeature.NEW_FOLDER}
     * @see #showFileDialog(String, File, boolean, Predicate, Consumer)
     */
    public static Dialog showFileDialog(String title, File dir, boolean isSelector, @Nullable Predicate<FileNode> valid,
                                        int features, Consumer<File> result) {
        return showFileDialog(title, dir, isSelector, null, valid, features, result);
    }

    /**
     * Shows a file dialog for selecting or creating files.
     * This dialog will display a tree list of files and directories starting from the specified directory.
     * You can use the text field to filter or specify the file name.
     * The dialog will have a confirm button to select the file or directory, and a cancel button to close the dialog.
     * You can also provide a predicate to validate the selected file or directory.
     * Don't forget to call {@link Dialog#show(UIElement)} to display the dialog.
     * @param title the title of the dialog
     * @param dir the directory to start from, it will be created if it does not exist
     * @param isSelector if true, the dialog will allow selecting a file or directory, otherwise it will allow creating a new file in the selected directory
     * @param defaultValue the default file or directory to select or prefill, can be null
     * @param valid a predicate to validate the selected file or directory, can be null to allow all files
     * @param result a consumer that will receive the selected file or directory when the confirm button is clicked
     */
    public static Dialog showFileDialog(String title, File dir, boolean isSelector, @Nullable File defaultValue, @Nullable Predicate<FileNode> valid, Consumer<File> result) {
        return showFileDialog(title, dir, isSelector, defaultValue, valid, FileFeature.ALL, result);
    }

    /**
     * Shows a file dialog offering only the given {@link FileFeature}s.
     *
     * @param features the enabled features, e.g. {@code FileFeature.OPEN_FOLDER | FileFeature.NEW_FOLDER}
     * @see #showFileDialog(String, File, boolean, File, Predicate, Consumer)
     */
    public static Dialog showFileDialog(String title, File dir, boolean isSelector, @Nullable File defaultValue,
                                        @Nullable Predicate<FileNode> valid, int features, Consumer<File> result) {
        var dialog = new Dialog().setAutoClose(false);
        var textField = new TextField();
        var treeList = new TreeList<FileNode>();
        if (!dir.isDirectory()) {
            if (!dir.mkdirs()) {
                return dialog;
            }
        }
        var root = new FileNode(dir).setValid(valid);
        var pickingFolder = new AtomicBoolean();
        dialog.overlay.layout(layout -> layout.width(240).maxWidthPercent(95));
        dialog.setTitle(title);
        Supplier<File> typedTarget = () -> FileDialogActions.typedTarget(textField.getText(), isSelector,
                new File("").getAbsoluteFile(), FileDialogActions.openTargetDir(treeList, dir));
        Consumer<File> navigate = target -> {
            if (!isInsideFileDialogRoot(dialog, dir, target)) return;
            if (FileDialogDefaults.resolve(root, isSelector, target).selectedNode() == null) {
                showFileDialogError(dialog, "editor.file_not_found");
            } else {
                applyFileDialogDefault(treeList, textField, root, isSelector, target);
            }
        };
        dialog.addContent(textField.layout(layout -> layout.widthPercent(100).minWidth(0).height(14)));
        var jumpButton = fileDialogToolButton(Icons.RIGHT, "ldlib.gui.file_dialog.jump_to", "__file-dialog_jump-to__")
                .setOnClick(e -> navigate.accept(typedTarget.get()));
        var openButton = fileDialogToolButton(Icons.FOLDER, "ldlib.gui.tips.open_folder", "__file-dialog_open-folder__").setOnClick(e -> {
            var target = typedTarget.get();
            if (!isInsideFileDialogRoot(dialog, dir, target)) return;
            var folder = FileDialogActions.navigationDirectory(target, !isSelector);
            if (folder == null) showFileDialogError(dialog, "editor.file_not_found");
            else Util.getPlatform().openFile(folder);
        });
        var selectButton = fileDialogToolButton(Icons.OPEN_FILE, "ldlib.gui.file_dialog.select_folder", "__file-dialog_choose-folder__").setOnClick(e -> {
            if (!pickingFolder.compareAndSet(false, true)) return;
            var previousAutoClose = dialog.autoClose;
            dialog.setAutoClose(false);
            var target = typedTarget.get();
            var typedDir = target != null && FileDialogActions.isWithin(dir, target)
                    ? FileDialogActions.navigationDirectory(target, !isSelector) : null;
            var initialDir = typedDir != null ? typedDir : FileDialogActions.openTargetDir(treeList, dir);
            var initialName = isSelector || target == null || target.isDirectory() ? "" : target.getName();
            // the native picker takes no "." segments: given one it opens at its default location
            var initialPath = FileDialogDefaults.normalizeFile(initialDir).getPath();
            // The native modal may remain open for a while; keep rendering the game underneath it.
            CompletableFuture.supplyAsync(() -> TinyFileDialogs.tinyfd_selectFolderDialog(
                    Component.translatable(title).getString(), initialPath))
                    .whenComplete((path, error) -> Minecraft.getInstance().execute(() -> {
                        pickingFolder.set(false);
                        dialog.setAutoClose(previousAutoClose);
                        if (dialog.getParent() == null) return;
                        dialog.focus();
                        if (error != null) {
                            Dialog.showNotification("editor.error", "ldlib.gui.file_dialog.failed", null).show(dialog.getParent());
                            return;
                        }
                        if (path == null || path.isBlank()) return;
                        var folder = new File(path);
                        if (!folder.isDirectory()) return;
                        navigate.accept(initialName.isEmpty() ? folder : new File(folder, initialName));
                    }));
        });
        dialog.addContent(new UIElement().layout(layout -> layout.widthPercent(100)
                        .flexDirection(FlexDirection.ROW).gapAll(2))
                .setDisplay(FileFeature.has(features, FileFeature.OPEN_FOLDER))
                .addChildren(jumpButton, openButton, selectButton));
        treeList.setOnSelectedChanged(selected -> {
            if (selected.isEmpty()) return;
            var first = selected.stream().findFirst().get();
            if (isSelector) {
                textField.setText(first.getKey().toString(), false);
            } else if (first.isFile()) {
                textField.setText(first.getKey().getName(), false);
            } else {
                textField.setText("", false);
            }
        }).setOnDoubleClickNode(node -> {
            var file = node.getKey();
            if (isSelector && node.isFile()) {
                dialog.close();
                if (result != null) result.accept(file);
            }
        }).setNodeUISupplier(TreeList.iconTextTemplate(
                node -> node.isDirectory() ?
                        Icons.FOLDER :
                        Icons.getIcon(node.getKey().getName()
                                .substring(node.getKey().getName().lastIndexOf('.') + 1)),
                node -> Component.translatable(node.getKey().getName())))
                .setRoot(root);
        applyFileDialogDefault(treeList, textField, root, isSelector, defaultValue);
        var scrollerView = new ScrollerView().addScrollViewChild(treeList).layout(layout -> {
            layout.widthPercent(100);
            layout.height(180);
        });
        // new folder / rename / delete. Listening on the scroller so a right click below the last row
        // still offers to create a folder in the root.
        scrollerView.addEventListener(UIEvents.MOUSE_DOWN, e -> {
            if (e.button == 1) {
                FileDialogActions.openContextMenu(dialog, treeList, root, features, e.x, e.y);
            }
        });
        dialog.addContent(scrollerView);
        dialog.addButton(new Button()
                .setOnClick(e -> {
                    var parent = dialog.getParent();
                    dialog.close();
                    if (result == null) return;
                    if (isSelector) {
                        if (textField.getText().isEmpty()) {
                            return;
                        }
                        var file = new File(textField.getText());
                        if (!FileDialogActions.isWithin(dir, file)) {
                            if (parent != null) Dialog.showNotification("editor.error", "ldlib.gui.file_dialog.outside_root", null).show(parent);
                        } else if (file.isDirectory() || file.exists()) {
                            result.accept(file);
                        } else if (parent != null){
                            Dialog.showNotification("editor.error", "editor.file_not_found", null).show(parent);
                        }
                    } else {
                        var nodes = treeList.getSelected();
                        if (!nodes.isEmpty()) {
                            var first = nodes.stream().findFirst().get();
                            var file = first.getKey();
                            var fileName = textField.getText();
                            if (file.isFile()) {
                                file = file.getParentFile();
                            }
                            if (!file.isDirectory()) return;
                            var picked = new File(file, fileName);
                            if (FileDialogActions.isWithin(dir, picked)) {
                                result.accept(picked);
                            } else if (parent != null) {
                                Dialog.showNotification("editor.error", "ldlib.gui.file_dialog.outside_root", null).show(parent);
                            }
                        }
                    }
                })
                .setText("ldlib.gui.tips.confirm")
                .addClass("__confirm-button__"));
        dialog.addButton(new Button()
                .setOnClick(e -> dialog.close())
                .setText("ldlib.gui.tips.cancel")
                .addClass("__cancel-button__"));
        return dialog;
    }

    private static Button fileDialogToolButton(com.lowdragmc.lowdraglib2.gui.texture.IGuiTexture icon, String tooltip, String clazz) {
        var button = new Button().noText();
        button.addClass(clazz);
        button.layout(layout -> layout.width(14).height(14).flexShrink(0).paddingAll(3));
        button.style(style -> style.tooltips(tooltip));
        button.addChild(new UIElement().addClass("__white_icon__")
                .layout(layout -> layout.widthPercent(100).heightPercent(100))
                .style(style -> style.backgroundTexture(icon)));
        return button;
    }

    /** Everything the dialog shows or picks is inside {@code root}. */
    private static boolean isInsideFileDialogRoot(Dialog dialog, File root, @Nullable File target) {
        if (target == null) {
            showFileDialogError(dialog, "editor.file_not_found");
            return false;
        }
        if (!FileDialogActions.isWithin(root, target)) {
            showFileDialogError(dialog, "ldlib.gui.file_dialog.outside_root");
            return false;
        }
        return true;
    }

    private static void showFileDialogError(Dialog dialog, String info) {
        var parent = dialog.getParent();
        if (parent == null) return;
        var error = Dialog.showNotification("editor.error", info, null);
        dialog.addExternalElement(error);
        error.setOnClose(() -> dialog.removeExternalElement(error));
        error.show(parent);
    }

    static void applyFileDialogDefault(TreeList<FileNode> treeList, TextField textField, FileNode root, boolean isSelector, @Nullable File defaultValue) {
        var fileDialogDefault = FileDialogDefaults.resolve(root, isSelector, defaultValue);
        var selectedNode = fileDialogDefault.selectedNode();
        if (selectedNode != null) {
            treeList.expandNodeAlongPath(selectedNode);
            selectedNode = findDisplayedFileNode(treeList, selectedNode);
            treeList.setSelected(List.of(selectedNode), false);
        }
        if (defaultValue != null) {
            textField.setText(fileDialogDefault.text(), false);
        }
    }

    private static FileNode findDisplayedFileNode(TreeList<FileNode> treeList, FileNode target) {
        for (var node : treeList.getNodeUIs().keySet()) {
            if (node.getDimension() == target.getDimension() && FileDialogDefaults.normalizeFile(node.getKey()).equals(FileDialogDefaults.normalizeFile(target.getKey()))) {
                return node;
            }
        }
        return target;
    }

    /**
     * Creates a predicate that filters out nodes based on their suffixes.
     * @param suffixes the suffixes to filter out, e.g. ".txt", ".jpg"
     */
    public static Predicate<FileNode> suffixFilter(String... suffixes) {
        return node -> {
            for (String suffix : suffixes) {
                // isFile() over getKey().isFile(): same answer, from the listing instead of a fresh stat
                if (!node.isFile() || node.getKey().getName().toLowerCase().endsWith(suffix.toLowerCase())) {
                    return true;
                }
            }
            return false;
        };
    }

    @Override
    public void drawBackgroundAdditional(@NotNull GUIContext guiContext) {
        super.drawBackgroundAdditional(guiContext);
        if (windowMode && !isResizing) {
            WindowDragHelper.drawResizeIcon(guiContext, overlay, 2);
        }
    }
}
