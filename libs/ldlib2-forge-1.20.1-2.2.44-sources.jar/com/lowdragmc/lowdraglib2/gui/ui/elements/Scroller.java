package com.lowdragmc.lowdraglib2.gui.ui.elements;

import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigSetter;
import com.lowdragmc.lowdraglib2.configurator.annotation.Configurable;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.ui.Style;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvent;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.ui.style.Property;
import com.lowdragmc.lowdraglib2.gui.ui.style.PropertyRegistry;
import com.lowdragmc.lowdraglib2.gui.ui.styletemplate.Sprites;
import com.lowdragmc.lowdraglib2.integration.kjs.KJSBindings;
import com.lowdragmc.lowdraglib2.registry.annotation.LDLRegister;
import com.lowdragmc.lowdraglib2.utils.XmlUtils;
import dev.vfyjxf.taffy.style.AlignItems;
import dev.vfyjxf.taffy.style.FlexDirection;
import it.unimi.dsi.fastutil.floats.FloatConsumer;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import net.minecraft.MethodsReturnNonnullByDefault;
import org.jetbrains.annotations.Nullable;
import org.w3c.dom.Element;

import javax.annotation.ParametersAreNonnullByDefault;
import java.util.function.Consumer;
import java.util.function.Function;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public abstract class Scroller extends BindableUIElement<Float> {
    @Configurable(name = "ScrollerStyle")
    public class ScrollerStyle extends Style {
        private static final Property<?>[] PROPERTIES = new Property[] {
                PropertyRegistry.SCROLL_DELTA,
                PropertyRegistry.SCROLL_BAR_SIZE,
        };

        public ScrollerStyle() {
            super(Scroller.this);
        }

        public static void init() {
            PropertyRegistry.SCROLL_BAR_SIZE.addListener(ScrollerStyle::onPropertyChanged);
        }

        private static <T> void onPropertyChanged(UIElement element, Property<T> property, @Nullable T oldValue, @Nullable T newValue) {
            if (element instanceof Scroller progressBar && property == PropertyRegistry.SCROLL_BAR_SIZE) {
                progressBar.updateScrollBarPosition();
            }
        }

        @Override
        protected Property<?>[] getProperties() {
            return PROPERTIES;
        }

        public ScrollerStyle scrollDelta(float scrollDelta) {
            set(PropertyRegistry.SCROLL_DELTA, scrollDelta);
            return this;
        }

        public float scrollDelta() {
            return getValueSave(PropertyRegistry.SCROLL_DELTA);
        }

        public ScrollerStyle scrollBarSize(float scrollBarSize) {
            var newSize = Math.max(0, Math.min(100, scrollBarSize));
            set(PropertyRegistry.SCROLL_BAR_SIZE, newSize);
            return this;
        }

        public float scrollBarSize() {
            return getValueSave(PropertyRegistry.SCROLL_BAR_SIZE);
        }
    }


    public final Button headButton;
    public final Button tailButton;
    public final UIElement scrollContainer;
    public final Button scrollBar;
    @Getter
    private final ScrollerStyle scrollerStyle = new ScrollerStyle();
    @Getter
    @Configurable(name = "minValue")
    protected float minValue = 0;
    @Getter
    @Configurable(name = "maxValue")
    protected float maxValue = 1;
    @Configurable(name = "value")
    protected float value = 0;
    @Getter @Setter
    @Accessors(chain = true)
    protected Function<Float, Float> clampNormalizedValue = Function.identity();
    // runtime
    @Getter
    protected boolean isDragging = false;

    public Scroller() {
        getLayout().alignItems(AlignItems.CENTER);
        this.headButton = new Button();
        this.tailButton = new Button();
        this.scrollContainer = new UIElement();
        this.scrollBar = new Button();
        this.headButton.addClass("__scroller_head_button__");
        this.tailButton.addClass("__scroller_tail_button__");
        this.scrollContainer.addClass("__scroller_scroll_container__");
        this.scrollBar.addClass("__scroller_scroll_bar__");

        this.headButton.noText().layout(layout -> {
            layout.width(5);
            layout.height(5);
        });
        this.headButton.setOnClick(e -> moveHead());

        this.tailButton.noText().layout(layout -> {
            layout.width(5);
            layout.height(5);
        });
        this.tailButton.setOnClick(e -> moveTail());

        this.scrollContainer.layout(layout -> {
            layout.alignSelf(AlignItems.STRETCH);
            layout.setFlexGrow(1);
        }).addChild(new UIElement().layout(layout -> layout.flex(1)).addChild(scrollBar));
        scrollBar.noText().layout(layout -> {
            layout.widthPercent(100);
            layout.heightPercent(100);
        });
        scrollBar.addEventListener(UIEvents.MOUSE_DOWN, e -> {
            scrollBar.startDrag(getValue(), null);
            isDragging = true;
            e.stopPropagation();
        });
        scrollBar.addEventListener(UIEvents.DRAG_SOURCE_UPDATE, this::onDraggingScrollBar);
        scrollBar.addEventListener(UIEvents.DRAG_END, e -> {
            isDragging = false;
            scrollBar.setButtonState(Button.State.DEFAULT);
        });
        // do not modify the scroll bar texture during dragging
        scrollContainer.addEventListener(UIEvents.MOUSE_LEAVE, e -> {
            if (e.target == scrollBar && isDragging) e.stopPropagation();
        }, true);
        scrollContainer.addEventListener(UIEvents.MOUSE_ENTER, e -> {
            if (e.target == scrollBar && isDragging) e.stopPropagation();
        }, true);
        scrollContainer.addEventListener(UIEvents.MOUSE_DOWN, this::clickScrollContainer);
        addChildren(headButton, scrollContainer, tailButton);
        scrollContainer.addEventListener(UIEvents.MOUSE_WHEEL, this::onScrollWheel);
    }

    public Scroller scrollerStyle(Consumer<ScrollerStyle> style) {
        style.accept(scrollerStyle);
        return this;
    }

    public void scrollValue(float normalizedValue) {
        setNormalizedValue(getNormalizedValue() + clampNormalizedValue.apply(normalizedValue));
    }

    /**
     * Scrolls one notch in the direction {@code delta} implies, or not at all when it is zero.
     *
     * <p>Takes a raw wheel delta rather than the event, so that the caller decides which axis of the
     * wheel drives this scroller. That is not always the obvious one — see {@code ScrollerView}, where
     * holding shift swaps them.
     */
    public void scrollByWheel(double delta) {
        if (delta == 0) return;
        var step = getScrollerStyle().scrollDelta();
        scrollValue(delta > 0 ? -step : step);
    }

    @ConfigSetter(field = "minValue")
    public Scroller setMinValue(float minValue) {
        return setRange(minValue, maxValue);
    }

    @ConfigSetter(field = "maxValue")
    public Scroller setMaxValue(float maxValue) {
        return setRange(minValue, maxValue);
    }

    /**
     * Set the range of the scroller.
     */
    public Scroller setRange(float minValue, float maxValue) {
        this.minValue = minValue;
        this.maxValue = maxValue;
        return setValue(value);
    }

    @ConfigSetter(field = "value")
    private void setValueEditor(float value) {
        setValue(value);
    }

    /**
     * Set the value of the scroller.
     */
    public Scroller setValue(@Nullable Float value, boolean notifyChange) {
        if (value == null) value = 0f;
        var newValue = Math.max(minValue, Math.min(maxValue, value));
        if (newValue != this.value) {
            this.value = newValue;
            updateScrollBarPosition();
            if (notifyChange) {
                notifyListeners();
            }
        }
        return this;
    }

    public Scroller setOnValueChanged(FloatConsumer onValueChanged) {
        registerValueListener(v -> onValueChanged.accept(v.floatValue()));
        return this;
    }

    public Scroller setValue(Float value) {
        return setValue(value, true);
    }

    public Float getValue() {
        return value;
    }

    public Scroller setNormalizedValue(float normalizedValue, boolean notifyChange) {
        return setValue(minValue + (maxValue - minValue) * normalizedValue, notifyChange);
    }

    public Scroller setNormalizedValue(float normalizedValue) {
        return setNormalizedValue(normalizedValue, true);
    }

    /**
     * Set the size of the scroll bar in percent.
     * @param size the size of the scroll bar in percent (0-100)
     */
    public Scroller setScrollBarSize(float size) {
        this.scrollerStyle.scrollBarSize(size);
        return this;
    }

    private void moveHead() {
        var newValue = value - (maxValue - minValue) * scrollerStyle.scrollDelta();
        setValue(newValue);
    }

    private void moveTail() {
        var newValue = value + (maxValue - minValue) * scrollerStyle.scrollDelta();
        setValue(newValue);
    }

    protected abstract void updateScrollBarPosition();

    protected abstract void onDraggingScrollBar(UIEvent event);

    protected abstract void clickScrollContainer(UIEvent event);

    protected abstract void onScrollWheel(UIEvent event);

    public float getNormalizedValue() {
        return maxValue == minValue ? Float.NaN : (value - minValue) / (maxValue - minValue);
    }

    public Scroller headButton(Consumer<Button> button) {
        button.accept(headButton);
        return this;
    }

    public Scroller tailButton(Consumer<Button> button) {
        button.accept(tailButton);
        return this;
    }

    public Scroller scrollContainer(Consumer<UIElement> container) {
        container.accept(scrollContainer);
        return this;
    }

    public Scroller scrollBar(Consumer<Button> button) {
        button.accept(scrollBar);
        return this;
    }

    @KJSBindings("ScrollerVertical")
    @LDLRegister(name = "scroller-vertical", group = "utils", registry = "ldlib2:ui_element")
    public static class Vertical extends Scroller {
        public Vertical() {
            getLayout().flexDirection(FlexDirection.COLUMN);
            getLayout().gapRow(1);
            getLayout().width(5);

            headButton.buttonStyle(style -> style
                    .baseTexture(Icons.UP_ARROW_NO_BAR_S)
                    .hoverTexture(Icons.UP_ARROW_NO_BAR_S_LIGHT)
                    .pressedTexture(Icons.UP_ARROW_NO_BAR_S_WHITE)
            );
            tailButton.buttonStyle(style -> style
                    .baseTexture(Icons.DOWN_ARROW_NO_BAR_S)
                    .hoverTexture(Icons.DOWN_ARROW_NO_BAR_S_LIGHT)
                    .pressedTexture(Icons.DOWN_ARROW_NO_BAR_S_WHITE)
            );
            scrollContainer.style(style -> style.backgroundTexture(Sprites.SCROLL_CONTAINER_V));
            scrollBar.buttonStyle(style -> style
                    .baseTexture(Sprites.SCROLL_BAR_V)
                    .hoverTexture(Sprites.SCROLL_BAR_LIGHT_V)
                    .pressedTexture(Sprites.SCROLL_BAR_WHITE_V)
            );
            updateScrollBarPosition();
            internalSetup();
        }

        @Override
        protected void updateScrollBarPosition()  {
            var scrollBarSize = getScrollerStyle().scrollBarSize();
            float remainingSpace = 100 - scrollBarSize;
            float position = getNormalizedValue() * remainingSpace;
            Style.importantPipeline(scrollBar.getLayout(), layout -> {
                layout.heightPercent(scrollBarSize);
                layout.topPercent(position);
            });
        }

        @Override
        protected void onDraggingScrollBar(UIEvent event) {
            if (event.dragHandler.draggingObject instanceof Float initialValue) {
                var minY = scrollContainer.getContentY();
                var maxY = scrollContainer.getContentY() + scrollContainer.getContentHeight();

                var remainingSpace = maxY - minY - scrollBar.getSizeHeight();
                var localMouse = getLocalMouse(event.x, event.y);
                var localStart = getLocalMouse(event.dragStartX, event.dragStartY);
                var deltaY = localMouse.y - localStart.y;
                var distValue = (deltaY / remainingSpace) * (maxValue - minValue);
                var newValue = distValue + initialValue;
                setValue(newValue);
            }
        }

        @Override
        protected void clickScrollContainer(UIEvent event) {
            if (event.button == 0) {
                setValue(minValue + (maxValue - minValue) * (getLocalMouse(event.x, event.y).y - scrollContainer.getContentY()) / scrollContainer.getContentHeight());
            }
        }

        @Override
        protected void onScrollWheel(UIEvent event) {
            scrollByWheel(event.deltaY);
        }
    }

    @KJSBindings("ScrollerHorizontal")
    @LDLRegister(name = "scroller-horizontal", group = "utils", registry = "ldlib2:ui_element")
    public static class Horizontal extends Scroller {
        public Horizontal() {
            getLayout().flexDirection(FlexDirection.ROW);
            getLayout().gapColumn(1);
            getLayout().height(5);

            headButton.buttonStyle(style -> style
                    .baseTexture(Icons.LEFT_ARROW_NO_BAR_S)
                    .hoverTexture(Icons.LEFT_ARROW_NO_BAR_S_LIGHT)
                    .pressedTexture(Icons.LEFT_ARROW_NO_BAR_S_WHITE)
            );
            tailButton.buttonStyle(style -> style
                    .baseTexture(Icons.RIGHT_ARROW_NO_BAR_S)
                    .hoverTexture(Icons.RIGHT_ARROW_NO_BAR_S_LIGHT)
                    .pressedTexture(Icons.RIGHT_ARROW_NO_BAR_S_WHITE)
            );
            scrollContainer.style(style -> style.backgroundTexture(Sprites.SCROLL_CONTAINER_H));
            scrollBar.buttonStyle(style -> style
                    .baseTexture(Sprites.SCROLL_BAR_H)
                    .hoverTexture(Sprites.SCROLL_BAR_LIGHT_H)
                    .pressedTexture(Sprites.SCROLL_BAR_WHITE_H)
            );
            updateScrollBarPosition();
            internalSetup();
        }

        @Override
        protected void updateScrollBarPosition() {
            var scrollBarSize = getScrollerStyle().scrollBarSize();
            float remainingSpace = 100 - scrollBarSize;
            float position = getNormalizedValue() * remainingSpace;

            Style.importantPipeline(scrollBar.getLayout(), layout -> {
                layout.widthPercent(scrollBarSize);
                layout.leftPercent(position);
            });
        }

        @Override
        protected void onDraggingScrollBar(UIEvent event) {
            if (event.dragHandler.draggingObject instanceof Float initialValue) {
                var minX = scrollContainer.getContentX();
                var maxX = scrollContainer.getContentX() + scrollContainer.getContentWidth();

                var remainingSpace = maxX - minX - scrollBar.getSizeWidth();
                var localMouse = getLocalMouse(event.x, event.y);
                var localStart = getLocalMouse(event.dragStartX, event.dragStartY);
                var deltaX = localMouse.x - localStart.x;
                var distValue = (deltaX / remainingSpace) * (maxValue - minValue);
                var newValue = distValue + initialValue;
                setValue(newValue);
            }
        }

        @Override
        protected void clickScrollContainer(UIEvent event) {
            if (event.button == 0) {
                setValue(minValue + (maxValue - minValue) * (getLocalMouse(event.x, event.y).x - scrollContainer.getContentX()) / scrollContainer.getContentWidth());
            }
        }

        @Override
        protected void onScrollWheel(UIEvent event) {
            // Falls back to the vertical wheel, because almost no mouse has a horizontal one and a
            // scroller on its own would otherwise be unreachable by wheel at all.
            scrollByWheel(event.deltaX != 0 ? event.deltaX : event.deltaY);
        }
    }

    /// Editor + Xml
    @Override
    public void loadXml(Element element) {
        // min value
        if (element.hasAttribute("min-value")) {
            setMinValue(XmlUtils.getAsFloat(element, "min-value", minValue));
        }
        // max value
        if (element.hasAttribute("max-value")) {
            setMaxValue(XmlUtils.getAsFloat(element, "max-value", maxValue));
        }
        // value
        if (element.hasAttribute("value")) {
            setValue(XmlUtils.getAsFloat(element, "value", value));
        }
        super.loadXml(element);
    }
}
