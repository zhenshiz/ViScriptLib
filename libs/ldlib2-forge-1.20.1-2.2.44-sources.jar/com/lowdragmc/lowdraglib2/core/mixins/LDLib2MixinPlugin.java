package com.lowdragmc.lowdraglib2.core.mixins;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public class LDLib2MixinPlugin implements IMixinConfigPlugin, MixinPluginShared {
    @Override
    public void onLoad(String mixinPackage) {

    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (mixinClassName.contains("com.lowdragmc.lowdraglib2.core.mixins.jei")) {
            return IS_JEI_LOAD;
        } else if (mixinClassName.contains("com.lowdragmc.lowdraglib2.core.mixins.rei")) {
            return IS_REI_LOAD;
        } else if (mixinClassName.contains("com.lowdragmc.lowdraglib2.core.mixins.emi")) {
            return IS_EMI_LOADED;
        } else if (mixinClassName.contains("com.lowdragmc.lowdraglib2.core.mixins.kjs")) {
            return IS_KJS_LOAD;
        }
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {

    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }
}
