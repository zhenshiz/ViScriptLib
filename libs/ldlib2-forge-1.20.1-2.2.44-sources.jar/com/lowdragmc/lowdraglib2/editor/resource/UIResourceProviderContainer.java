package com.lowdragmc.lowdraglib2.editor.resource;

import com.google.common.collect.Maps;
import com.lowdragmc.lowdraglib2.editor.ui.resource.ResourceProviderContainer;
import com.lowdragmc.lowdraglib2.gui.editor.view.UIEditorView;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.UITemplate;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.ui.style.StylesheetManager;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Tuple;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

public class UIResourceProviderContainer extends ResourceProviderContainer<UITemplate> {
    // static: one template is reachable from more than one container, and a rename made through either has to reach
    // the editor the other opened
    private static final Map<UUID, Tuple<IResourcePath, UIEditorView>> OPENED_VIEWS = Maps.newHashMap();

    public UIResourceProviderContainer(IResourceProvider<UITemplate> provider) {
        super(provider);
        // A built-in cannot be edited, but it is exactly the thing worth looking at: it is how a mod
        // shows the way one of its UIs is put together, and the starting point for someone who wants
        // their own. Opening is therefore always allowed; whether the view writes back is decided
        // below, from the same canEdit answer.
        setCanOpen(path -> true);
        setAddDefault(() -> UITemplate.of(new UIElement().layout(layout -> {
            layout.width(150);
            layout.height(150);
        }).addClass("panel_bg"), StylesheetManager.GDP)
        ).setUiSupplier(path -> new UIElement().layout(layout -> {
            layout.widthPercent(100);
            layout.heightPercent(100);
        }).style(style -> style.backgroundTexture(Icons.WIDGET_BASIC)))
        .setOnEdit((container, path) -> {
            if (selectOpenedView(OPENED_VIEWS.values(), path)) return;

            var template = provider.getResource(path);
            if (template == null) return;
            var editor = container.getEditor();
            var uuid = UUID.randomUUID();
            var editable = provider.canEdit(path);

            // A null save handler is what makes the view read-only: UIEditorView only writes back
            // when it has one, so a built-in can be opened and read without any way to change it.
            var newView = new UIEditorView().loadTemplate(template, !editable ? null : newTemplate -> {
                if (!OPENED_VIEWS.containsKey(uuid)) {
                    // invalid already.
                    return;
                }
                var realPath = OPENED_VIEWS.get(uuid).getA();
                provider.addResource(realPath, newTemplate);
                container.reloadSpecificResource(realPath);
            });
            // cache path for renaming cases
            AtomicReference<IResourcePath> pathCache = new AtomicReference<>(path);
            newView.addEventListener(UIEvents.ADDED, e -> {
                OPENED_VIEWS.put(uuid, new Tuple<>(pathCache.get(), newView));
            });
            newView.addEventListener(UIEvents.REMOVED, e -> {
                var pair = OPENED_VIEWS.remove(uuid);
                if (pair != null) {
                    pathCache.set(pair.getA());
                }
            });
            newView.setCanRemove(true);
            newView.setIcon(Icons.WIDGET_BASIC);
            newView.setDynamicName(() -> {
                // the provider's name for it, as the resource panel shows it
                var name = resourceProvider.getResourceName(OPENED_VIEWS.containsKey(uuid)
                        ? OPENED_VIEWS.get(uuid).getA() : pathCache.get());
                // Said in the tab rather than left to be discovered: a view that silently discards
                // edits is worse than one that will not take them.
                return Component.literal(editable ? name : name + " (read-only)");
            });
            editor.placeView(newView, () -> editor.centerWindow.getLeftTop());
            bringToFront(newView);
        });
    }

    @Override
    protected void onResourceMoved(IResourcePath from, IResourcePath to) {
        // update open view name as well
        for (var openedView : OPENED_VIEWS.values()) {
            if (openedView.getA().equals(from)) {
                openedView.setA(to);
            }
        }
    }
}
