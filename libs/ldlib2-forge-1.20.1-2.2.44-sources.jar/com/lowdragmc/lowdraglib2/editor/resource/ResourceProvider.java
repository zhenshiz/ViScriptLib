package com.lowdragmc.lowdraglib2.editor.resource;

import lombok.Getter;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

@Accessors(chain = true)
public abstract class ResourceProvider<T> implements IResourceProvider<T> {
    @Getter
    public final ResourceInstance<T> resourceInstance;
    @Getter
    protected final Map<IResourcePath, T> contents = new LinkedHashMap<>();

    protected ResourceProvider(ResourceInstance<T> resourceHolder) {
        this.resourceInstance = resourceHolder;
    }

    public abstract boolean supportResourcePath(IResourcePath path);

    public boolean hasResource(IResourcePath path) {
        if (!supportResourcePath(path)) return false;
        return contents.containsKey(path);
    }

    @Override
    public T getResource(IResourcePath path) {
        if (supportResourcePath(path) && contents.containsKey(path)) {
            return contents.get(path);
        }
        return null;
    }

    @Override
    public T getLoadedResource(IResourcePath path) {
        return contents.get(path);
    }

    public boolean addResource(IResourcePath path, T resource) {
        if (resource == null) return false;
        if (!supportResourcePath(path)) return false;
        if (contents.put(path, resource) != null) {
            resourceInstance.clearCache();
        }
        return true;
    }

    public boolean addResource(String name, T resource) {
        return addResource(createSubPath(name), resource);
    }

    public T removeResource(IResourcePath path) {
        if (supportResourcePath(path) && contents.containsKey(path)) {
            var removed = contents.remove(path);
            if (removed != null) {
                resourceInstance.clearCache();
            }
            return removed;
        }
        return null;
    }

    public T removeResource(String name) {
        return removeResource(createSubPath(name));
    }

    @Override
    public boolean canRemove(IResourcePath path) {
        return supportResourcePath(path);
    }

    @Override
    public boolean canRename(IResourcePath path) {
        return supportResourcePath(path);
    }

    @Override
    public boolean canEdit(IResourcePath path) {
        return supportResourcePath(path);
    }

    @Override
    public boolean canCopy(IResourcePath path) {
        return supportResourcePath(path);
    }

    @Override
    public @NotNull Iterator<Map.Entry<IResourcePath, T>> iterator() {
        return contents.entrySet().iterator();
    }
}
