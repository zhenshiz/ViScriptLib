package com.lowdragmc.lowdraglib2.editor.ui.sceneeditor.sceneobject;

import com.lowdragmc.lowdraglib2.math.Transform;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import org.jetbrains.annotations.Nullable;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * @author KilaBash
 * @date 2024/06/26
 * @implNote A scene object that can be placed in the scene editor.
 */
@OnlyIn(Dist.CLIENT)
public interface ISceneObject {
    /**
     * Get the unique id of the object.
     */
    default UUID id() {
        return transform().id();
    }

    /**
     * Get the transform of the object.
     */
    Transform transform();

    default void setTransform(Transform transform) {
        transform().set(transform);
    }

    /**
     * Get the scene.
     */
    @Nullable
    IScene getScene();

    /**
     * Set the scene internal. you should not call this method directly.
     */
    void setSceneInternal(IScene scene);

    /**
     * Sets the scene for the object and manages its association with the scene.
     * If the object is already part of another scene, it will be removed from that scene before being added to the new scene.
     * This method also updates the scene association for all child objects recursively.
     *
     * @param scene the scene to set for this object. Can be null to remove the object from its current scene.
     */
    default void setScene(@Nullable IScene scene) {
        if (getScene() != scene) {
            if (getScene() != null) {
                getScene().removeSceneObjectInternal(this);
            }
            setSceneInternal(scene);
            if (scene == null) {
                onDestroy();
            } else {
                scene.addSceneObjectInternal(this);
                awake();
            }
            children().forEach(child -> child.setScene(scene));
            if (scene != null) {
                transform().rebuildChildOrder();
            }
        }
    }

    default void destroy() {
        setScene(null);
    }

    default void onDestroy() {
        transform().destroy();
    }

    /**
     * Get the children of the object. (read-only)
     * if possible, please cache the children list. and update it when the children is changed. see {@link #onChildChanged()}
     */
    default List<ISceneObject> children() {
        return transform().children().stream().map(Transform::sceneObject).toList();
    }

    default List<ISceneObject> getAllFlatChildren() {
        List<ISceneObject> children = children();
        return children.stream().flatMap(child -> child.getAllFlatChildren().stream()).toList();
    }

    /**
     * Called when the transform of the object is changed.
     */
    default void onTransformChanged() {
    }

    /**
     * Called when the children of the object is changed.
     */
    default void onChildChanged() {
    }

    /**
     * Called when the parent of the object is changed.
     */
    default void onParentChanged() {

    }

    /**
     * Update the interactable per tick.
     */
    default void updateTick() {
    }

    /**
     * Update the interactable per frame.
     */
    default void updateFrame(float partialTicks) {
    }

    /**
     * Execute the consumer for the object and all children.
     */
    default void executeAll(Consumer<ISceneObject> consumer) {
        consumer.accept(this);
        children().forEach(child -> child.executeAll(consumer));
    }

    /**
     * Execute the consumer for the object and all children.
     */
    default void executeAll(Consumer<ISceneObject> consumer, @Nullable Consumer<ISceneObject> before, @Nullable Consumer<ISceneObject> after) {
        if (before != null) before.accept(this);
        consumer.accept(this);
        children().forEach(child -> child.executeAll(consumer));
        if (after != null) after.accept(this);
    }

    /**
     * it will be called when the scene objects are all added, but before the scene object is ready for used.
     */
    default void awake() {
        transform().awake();
    }

}
