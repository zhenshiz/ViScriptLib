package com.lowdragmc.lowdraglib2.editor.ui.browser;

import com.lowdragmc.lowdraglib2.editor.resource.*;
import com.lowdragmc.lowdraglib2.editor.ui.Editor;
import com.lowdragmc.lowdraglib2.editor.ui.resource.ResourceProviderContainer;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.util.TreeBuilder;
import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.*;
import java.util.function.Consumer;

/**
 * Bridges a plain directory on disk to the per-resource-type behavior the editor already defines.
 * <p>
 * Everything a resource type does with its own resources — the thumbnail, the double-click editor, the
 * "create new" menu entries, the drag payload, writing the file back — lives in
 * {@link Resource#createResourceProviderContainer(IResourceProvider)}. Rather than reimplementing any
 * of that, this cache builds a real {@link ResourceProviderContainer} per (directory, resource type)
 * pair and uses it as a behavior object.
 * <p>
 * The containers are {@link ResourceProviderContainer#isHeadless() headless} (they build no resource UI
 * of their own) and are added to the host element with display turned off. They must be real children:
 * some resource types show dialogs through {@code getModularUI()}, which is only populated when an
 * element is part of the UI tree. Because the framework skips ticking hidden children, the owner has to
 * call {@link #tick()} itself — that is what keeps dirty resources flushing to disk.
 */
public class ResourceBehaviorCache {
    /**
     * A resource type bound to one directory, together with its provider and behavior container.
     * <p>
     * The menu helpers live here rather than on the caller because they need the container and its
     * callbacks to agree on {@code T}; through a {@code Behavior<?>} each access would capture a fresh
     * wildcard and refuse to compile.
     */
    public record Behavior<T>(Resource<T> resource,
                              ResourceInstance<T> instance,
                              IResourceProvider<T> provider,
                              ResourceProviderContainer<T> container) {

        /** Whether the resource of the given path actually loaded. */
        public boolean isLoaded(@Nullable IResourcePath path) {
            return path != null && provider.hasResource(path);
        }

        /** The contextual entries this resource type adds to a resource's menu, e.g. "copy color". */
        public void appendContextMenu(TreeBuilder.Menu menu) {
            var onMenu = container.getOnMenu();
            if (onMenu != null) {
                onMenu.accept(container, menu);
            }
        }

        /** The entries that create a new resource of this type, as the resource panel offers them. */
        public void appendCreateMenu(TreeBuilder.Menu menu, Runnable onCreated) {
            var addDefault = container.getAddDefault();
            if (container.getSupportAdd().getAsBoolean() && addDefault != null) {
                menu.leaf(Icons.ADD_FILE, "ldlib.gui.editor.menu.add_resource", () -> {
                    var value = addDefault.get();
                    if (value != null) {
                        container.addNewResource(value);
                        onCreated.run();
                    }
                });
            }
            var onCreateMenu = container.getOnCreateMenu();
            if (onCreateMenu != null) {
                onCreateMenu.accept(container, menu);
            }
        }
    }

    private final UIElement host;
    private final Editor editor;
    private final Map<Resource<?>, Behavior<?>> behaviors = new LinkedHashMap<>();
    // what each behavior was built against, see tick()
    private final Map<Resource<?>, BuiltAgainst> builtAgainst = new HashMap<>();
    @Getter
    @Nullable
    private File directory;
    /** Notified with the affected path, or null meaning "everything", when a resource changed. */
    @Setter
    @Nullable
    private Consumer<IResourcePath> onResourceInvalidated;

    public ResourceBehaviorCache(UIElement host, Editor editor) {
        this.host = host;
        this.editor = editor;
        // the resource instances outlive the host: its own providers are known to them only while it is on show,
        // and a host that is only moved (floated, docked back) keeps its behaviors
        host.addEventListener(UIEvents.REMOVED, e -> setOwnProvidersKnown(false));
        host.addEventListener(UIEvents.ADDED, e -> setOwnProvidersKnown(true));
    }

    /**
     * The resource types the current editor knows about. Resolved lazily: the resource view is not
     * assigned yet while it is still being constructed.
     */
    public Collection<Resource<?>> availableResources() {
        if (editor == null || editor.resourceView == null) return List.of();
        return editor.resourceView.getResources().keySet();
    }

    public void setDirectory(@Nullable File directory) {
        if (Objects.equals(this.directory, directory)) return;
        dispose();
        this.directory = directory;
    }

    /**
     * The resource type able to load the given file, matched on the file extension. The LONGEST match
     * wins, so a type whose extension ends with another's (e.g. {@code .graph.nbt} vs
     * {@code .test_graph.nbt}) still resolves correctly.
     *
     * @return the owning resource type, or null when no loaded type claims this file.
     */
    @Nullable
    public Resource<?> resourceOf(@Nullable File file) {
        if (file == null || file.isDirectory()) return null;
        return resourceOfName(file);
    }

    /** The extension match on its own, for a caller that has already ruled out a directory. */
    @Nullable
    private Resource<?> resourceOfName(File file) {
        var name = file.getName();
        Resource<?> best = null;
        var bestLength = -1;
        for (var resource : availableResources()) {
            var extension = resource.getFileExtension();
            // strictly longer, so a file literally named ".texture.nbt" isn't treated as a resource
            if (name.length() > extension.length() && name.endsWith(extension) && extension.length() > bestLength) {
                best = resource;
                bestLength = extension.length();
            }
        }
        return best;
    }

    @Nullable
    public Behavior<?> forFile(@Nullable File file) {
        var resource = resourceOf(file);
        return resource == null ? null : get(resource);
    }

    /**
     * As {@link #forFile(File)}, for a file a listing has already established is not a directory. That
     * check is a stat syscall, and skipping it once per entry is what keeps a large folder cheap.
     */
    @Nullable
    public Behavior<?> forNonDirectory(File file) {
        var resource = resourceOfName(file);
        return resource == null ? null : get(resource);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public <T> Behavior<T> get(@Nullable Resource<T> resource) {
        if (resource == null || directory == null) return null;
        var cached = behaviors.get(resource);
        if (cached != null) return (Behavior<T>) cached;
        var behavior = create(resource, directory);
        behaviors.put(resource, behavior);
        return behavior;
    }

    /** The instance's providers version, and the folder's registered provider then (null when there was none). */
    private record BuiltAgainst(int providersVersion, @Nullable IResourceProvider<?> registered) {}

    private <T> Behavior<T> create(Resource<T> resource, File directory) {
        var instance = resource.getResourceInstance();
        var provider = findFileProvider(instance, directory);
        builtAgainst.put(resource, new BuiltAgainst(instance.getProvidersVersion(), provider));
        if (provider == null) {
            var created = new FileResourceProvider<T>(instance, directory);
            created.setName(directory.getName());
            // a dragged resource of this folder is referenced by its path, which the drop target looks up by value
            instance.addUnlistedProvider(created);
            provider = created;
        }
        var container = resource.createResourceProviderContainer(provider);
        container.setHeadless(true);
        container.setEditor(editor);
        container.setOnResourceInvalidated(path -> {
            // a resource was added/removed/edited on disk. The shared lookup cache may hold a stale
            // value, or a negative entry from before the file existed.
            instance.clearCache();
            if (onResourceInvalidated != null) {
                onResourceInvalidated.accept(path);
            }
        });
        container.setDisplay(false);
        host.addChild(container);
        return new Behavior<>(resource, instance, provider, container);
    }

    /**
     * The provider the resource instance already has for this exact directory. Preferred over one of the
     * cache's own, so browsing into a folder that is also shown as a provider tab shares one file cache
     * and one write path instead of running two providers over the same directory.
     */
    @SuppressWarnings("unchecked")
    @Nullable
    public static <T> IResourceProvider<T> findFileProvider(ResourceInstance<T> instance, File directory) {
        for (var providers : instance.getBuiltinProviders().values()) {
            for (var provider : providers) {
                if (provider instanceof FileResourceProvider<?> fileProvider &&
                        isSameDirectory(fileProvider.resourceLocation, directory)) {
                    return (IResourceProvider<T>) provider;
                }
            }
        }
        for (var providers : instance.getCustomProviders().values()) {
            for (var provider : providers) {
                if (provider instanceof FileResourceProvider<?> fileProvider &&
                        isSameDirectory(fileProvider.resourceLocation, directory)) {
                    return (IResourceProvider<T>) provider;
                }
            }
        }
        return null;
    }

    /** A provider read from the meta file and a listed folder need not spell the same path the same way. */
    private static boolean isSameDirectory(File a, File b) {
        if (a.equals(b)) return true;
        return a.toPath().toAbsolutePath().normalize().equals(b.toPath().toAbsolutePath().normalize());
    }

    /** Drops one type's behavior, so the next lookup builds it again against the registered providers. */
    public void invalidate(Resource<?> resource) {
        var behavior = behaviors.remove(resource);
        builtAgainst.remove(resource);
        if (behavior != null) {
            // flushes its dirty resources, nothing ticks it after this
            behavior.container().screenTick();
            release(behavior);
        }
    }

    private <T> void release(Behavior<T> behavior) {
        behavior.instance().removeUnlistedProvider(behavior.provider());
        host.removeChild(behavior.container());
    }

    private void setOwnProvidersKnown(boolean known) {
        for (var behavior : behaviors.values()) {
            var built = builtAgainst.get(behavior.resource());
            if (built != null && built.registered() == null) {
                setKnown(behavior, known);
            }
        }
    }

    private static <T> void setKnown(Behavior<T> behavior, boolean known) {
        if (known) {
            behavior.instance().addUnlistedProvider(behavior.provider());
        } else {
            behavior.instance().removeUnlistedProvider(behavior.provider());
        }
    }

    /**
     * The resource path of the given file within the current directory. Built from the {@link File}
     * object itself, because {@link FileResourceProvider#supportResourcePath} matches on the parent
     * directory of the file.
     */
    public IResourcePath pathOf(File file) {
        return new FilePath(file);
    }

    /**
     * Drives the behavior containers. They are hidden children, which the framework skips while
     * ticking, so this has to be called by the owner. It flushes dirty resources to disk and picks up
     * external changes to the directory. A behavior whose folder got or lost a registered provider since,
     * e.g. through "New → file" in a panel, is built again over the folder's registered provider.
     */
    public void tick() {
        // copied: a container's tick may add resources, which can create further behaviors
        for (var behavior : List.copyOf(behaviors.values())) {
            if (isStale(behavior)) {
                invalidate(behavior.resource());
                // what was built from it has to be built again too, the grid's cells
                if (onResourceInvalidated != null) {
                    onResourceInvalidated.accept(null);
                }
                continue;
            }
            behavior.container().screenTick();
        }
    }

    // only a change to this folder's own provider: a rebuild leaves an inspector opened through the old container
    // writing into it
    private boolean isStale(Behavior<?> behavior) {
        var built = builtAgainst.get(behavior.resource());
        var version = behavior.instance().getProvidersVersion();
        if (built == null || built.providersVersion() == version) return false;
        if (findFileProvider(behavior.instance(), directory) != built.registered()) return true;
        builtAgainst.put(behavior.resource(), new BuiltAgainst(version, built.registered()));
        return false;
    }

    public void dispose() {
        for (var resource : List.copyOf(behaviors.keySet())) {
            invalidate(resource);
        }
    }
}
